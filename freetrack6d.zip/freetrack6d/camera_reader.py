"""
Encapsulated Intel RealSense D435 camera reader.

"""

from __future__ import annotations

import argparse
import logging
import sys

import cv2
import numpy as np


def check_realsense_connection() -> bool:
    """Return True if at least one RealSense device is connected."""
    try:
        import pyrealsense2 as rs
        ctx = rs.context()
        return len(ctx.query_devices()) > 0
    except ImportError:
        return False


class RealSenseCameraReader:
    """High-level wrapper around pyrealsense2 for colour + aligned depth.

    Args:
        width:  stream width in pixels.
        height: stream height in pixels.
        fps:    stream frame rate.
    """

    def __init__(self, width: int = 1280, height: int = 720, fps: int = 30):
        import pyrealsense2 as rs

        self._rs = rs
        self._pipeline = rs.pipeline()
        config = rs.config()
        config.enable_stream(rs.stream.color, width, height,
                             rs.format.rgb8, fps)
        config.enable_stream(rs.stream.depth, width, height,
                             rs.format.z16, fps)

        self._profile = self._pipeline.start(config)
        self._align = rs.align(rs.stream.color)

        self._depth_scale = float(
            self._profile.get_device()
            .first_depth_sensor()
            .get_depth_scale()
        )

        intr = (
            self._profile
            .get_stream(rs.stream.color)
            .as_video_stream_profile()
            .get_intrinsics()
        )
        self._K = np.array([
            [intr.fx, 0.0, intr.ppx],
            [0.0, intr.fy, intr.ppy],
            [0.0, 0.0, 1.0],
        ], dtype=np.float64)

        self._width = width
        self._height = height
        self._fps = fps
        logging.info(
            "RealSense %dx%d@%dfps  depth_scale=%.6f",
            width, height, fps, self._depth_scale,
        )

    def get_intrinsics(self) -> np.ndarray:
        """Return the 3x3 camera intrinsic matrix K."""
        return self._K.copy()

    @property
    def depth_scale(self) -> float:
        return self._depth_scale

    @property
    def width(self) -> int:
        return self._width

    @property
    def height(self) -> int:
        return self._height

    def get_frame(
        self, timeout_ms: int = 5000,
    ) -> tuple[np.ndarray, np.ndarray, float] | None:
        """Grab one aligned colour + depth frame.

        Returns:
            ``(color_rgb, depth_metres, timestamp_sec)`` or ``None`` if
            the camera did not deliver a frame within *timeout_ms*.
        """
        rs = self._rs
        try:
            frames = self._pipeline.wait_for_frames(timeout_ms=timeout_ms)
        except RuntimeError:
            return None

        aligned = self._align.process(frames)
        color_frame = aligned.get_color_frame()
        depth_frame = aligned.get_depth_frame()
        if not color_frame or not depth_frame:
            return None

        color = np.asanyarray(color_frame.get_data())
        depth_raw = np.asanyarray(depth_frame.get_data())
        depth = depth_raw.astype(np.float64) * self._depth_scale
        depth[(depth < 0.001) | (depth >= 10.0)] = 0.0

        timestamp = color_frame.get_timestamp() / 1000.0
        return color, depth, timestamp

    def stop(self):
        """Stop the pipeline and release resources."""
        try:
            self._pipeline.stop()
        except Exception:
            pass
        logging.info("RealSense pipeline stopped")


# -- Independent entry point ---------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="RealSense D435 live preview (connectivity test)",
    )
    parser.add_argument("--width", type=int, default=1280)
    parser.add_argument("--height", type=int, default=720)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--depth", action="store_true",
                        help="Show depth colourmap alongside colour")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO,
                        format="%(levelname)s %(message)s")

    if not check_realsense_connection():
        print("[ERROR] No RealSense device found.", file=sys.stderr)
        return 1

    reader = RealSenseCameraReader(args.width, args.height, args.fps)
    K = reader.get_intrinsics()
    print(f"Camera intrinsics K:\n{K}")

    win = "RealSense Preview (q/Esc to quit)"
    cv2.namedWindow(win, cv2.WINDOW_NORMAL)

    try:
        while True:
            result = reader.get_frame()
            if result is None:
                continue
            color_rgb, depth_m, ts = result
            vis = cv2.cvtColor(color_rgb, cv2.COLOR_RGB2BGR)

            if args.depth:
                depth_vis = (depth_m * 1000).clip(0, 4000).astype(np.uint16)
                depth_color = cv2.applyColorMap(
                    cv2.convertScaleAbs(depth_vis, alpha=0.06),
                    cv2.COLORMAP_JET,
                )
                vis = np.hstack([vis, depth_color])

            cv2.putText(vis, f"t={ts:.3f}s", (10, 25),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 1,
                        cv2.LINE_AA)
            cv2.imshow(win, vis)
            key = cv2.waitKey(1) & 0xFF
            if key in (27, ord('q')):
                break
    finally:
        reader.stop()
        cv2.destroyAllWindows()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
