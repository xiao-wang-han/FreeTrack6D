"""
Coordinate transformation utilities for the conveyor grasping system.

"""

from __future__ import annotations

import argparse
import logging
import os
import re
import sys

import cv2
import numpy as np


# -- Calibration loading -------------------------------------------------------

def load_calibration(path: str) -> np.ndarray:
    """Load 4x4 T_cam_to_base from a text file.

    The file should contain a 4x4 matrix (space-separated values,
    as produced by numpy.savetxt).  Returns a (4, 4) float64 array.
    """
    T = np.loadtxt(path).reshape(4, 4).astype(np.float64)
    logging.info("Loaded T_cam_to_base from %s", path)
    return T


# -- Pose conversions ---------------------------------------------------------

def vertex_to_obb_center(
    pose_vertex: np.ndarray,
    to_origin_inv: np.ndarray,
) -> np.ndarray:
    """Convert FoundationPose vertex pose to OBB geometric-centre pose.

    ``to_origin_inv`` is ``np.linalg.inv(to_origin)`` where ``to_origin``
    comes from ``trimesh.bounds.oriented_bounds(mesh)``.
    """
    return pose_vertex @ to_origin_inv


def pose_cam_to_base(
    T_cam_to_base: np.ndarray,
    pose_in_cam: np.ndarray,
) -> np.ndarray:
    """Transform a 4x4 pose from camera frame to robot base frame."""
    return T_cam_to_base @ pose_in_cam


def pose4x4_to_pose6(pose: np.ndarray) -> np.ndarray:
    """Convert a 4x4 homogeneous pose to [x, y, z, rx, ry, rz].

    The rotation is encoded as a Rodrigues (axis-angle) vector,
    which is the format UR robots expect for ``movel(p[...])`` commands.
    """
    rvec, _ = cv2.Rodrigues(pose[:3, :3].astype(np.float64))
    return np.concatenate([pose[:3, 3], rvec.ravel()]).astype(np.float64)


def pose6_to_pose4x4(pose6: np.ndarray) -> np.ndarray:
    """Convert [x, y, z, rx, ry, rz] to a 4x4 homogeneous pose."""
    R, _ = cv2.Rodrigues(np.asarray(pose6[3:6], dtype=np.float64))
    T = np.eye(4, dtype=np.float64)
    T[:3, :3] = R
    T[:3, 3] = pose6[:3]
    return T


# -- Safety offset -------------------------------------------------------------

def apply_safety_offset(
    pose_in_cam: np.ndarray,
    to_origin_inv: np.ndarray,
    offset_m: float = 0.15,
) -> np.ndarray:
    """Move the OBB centre toward the camera by *offset_m* metres.

    In a typical eye-to-hand setup looking down at the conveyor, this
    effectively raises the target and creates clearance to avoid
    collisions.  The offset direction is along the camera-to-target ray.

    Returns a modified vertex-frame pose (i.e. the OBB centre shift is
    "folded back" into the vertex convention so downstream code can
    apply ``vertex_to_obb_center`` as usual).
    """
    if offset_m <= 0:
        return pose_in_cam.copy()
    T_center = pose_in_cam @ to_origin_inv
    p = T_center[:3, 3].astype(np.float64)
    dist = float(np.linalg.norm(p))
    if dist < 1e-4:
        return pose_in_cam.copy()
    shrink = min(offset_m, max(0.0, dist - 0.03))
    if shrink <= 0:
        return pose_in_cam.copy()
    direction = p / dist
    T_center_new = T_center.copy()
    T_center_new[:3, 3] = p - shrink * direction
    return T_center_new @ np.linalg.inv(to_origin_inv)


# -- Full arm-target pipeline --------------------------------------------------

def compute_arm_target(
    T_cam_to_base: np.ndarray,
    pose_vertex_in_cam: np.ndarray,
    to_origin_inv: np.ndarray,
    safety_offset_m: float = 0.15,
    grasp_yaw_deg: float = 0.0,
    align_to_target: bool = True,
) -> np.ndarray:
    """Full pipeline: vertex pose (camera) -> pose6 for movel (base).

    Steps:
      1. Convert vertex -> OBB geometric centre
      2. Transform camera -> base
      3. Apply safety offset: +safety_offset_m on base-frame Z axis
      4. Compute flange yaw from target orientation (Flange-X || Target-Y)
         or use fixed ``grasp_yaw_deg`` as fallback
      5. Return [x, y, z, rx, ry, rz]

    The safety offset is applied in the robot base frame (+Z is up),
    raising the target above the workpiece to create clearance.

    When ``align_to_target`` is True the flange X-axis is aligned to the
    horizontal projection of the target's Y-axis (green axis), so that
    Flange-X || Target-Y and Flange-Y || Target-Z.  ``grasp_yaw_deg``
    is added as an extra offset on top.
    """
    center_cam = vertex_to_obb_center(pose_vertex_in_cam, to_origin_inv)
    center_base = pose_cam_to_base(T_cam_to_base, center_cam)

    pos = center_base[:3, 3].astype(np.float64)
    if safety_offset_m > 0:
        pos[2] += safety_offset_m

    if align_to_target:
        yaw_rad = _extract_target_yaw(center_base)
        yaw_deg = float(np.degrees(yaw_rad)) + grasp_yaw_deg
    else:
        yaw_deg = grasp_yaw_deg

    R = _tool_z_down_rotation(yaw_deg)
    rvec, _ = cv2.Rodrigues(R)
    return np.concatenate([pos, rvec.ravel()]).astype(np.float64)


def _extract_target_yaw(center_base: np.ndarray) -> float:
    """Compute the yaw angle (rad) that aligns Flange-X to Target-Y.

    Projects the target's Y-axis (column 1 of the rotation matrix in
    base frame) onto the horizontal plane and returns atan2(y, x).
    Falls back to 0 when the projection is degenerate (target Y nearly
    vertical).
    """
    target_y = center_base[:3, 1].astype(np.float64)
    horiz_len = np.hypot(target_y[0], target_y[1])
    if horiz_len < 1e-6:
        return 0.0
    return float(np.arctan2(target_y[1], target_y[0]))


def _tool_z_down_rotation(yaw_deg: float = 0.0) -> np.ndarray:
    """Rotation matrix for UR TCP with tool-Z pointing straight down.

    Assumes the UR base +Z is up (standard table mount).
    ``yaw_deg`` rotates about the vertical axis.
    """
    psi = float(np.radians(yaw_deg))
    c, s = np.cos(psi), np.sin(psi)
    z = np.array([0.0, 0.0, -1.0])
    x = np.array([c, s, 0.0])
    y = np.cross(z, x)
    yn = float(np.linalg.norm(y))
    if yn < 1e-12:
        return np.eye(3)
    y /= yn
    x = np.cross(y, z)
    x /= float(np.linalg.norm(x))
    return np.column_stack([x, y, z]).astype(np.float64)


# -- Image projection ---------------------------------------------------------

def project_base_point_to_image(
    K: np.ndarray,
    T_cam_to_base: np.ndarray,
    point_base: np.ndarray,
) -> tuple[int, int] | None:
    """Project a 3D point in base frame to image pixel (u, v).

    Returns ``None`` if the point is behind the camera.
    """
    T_base_to_cam = np.linalg.inv(T_cam_to_base)
    p_hom = np.array([*point_base[:3], 1.0], dtype=np.float64)
    p_cam = (T_base_to_cam @ p_hom)[:3]
    if p_cam[2] <= 1e-4:
        return None
    u = K[0, 0] * p_cam[0] / p_cam[2] + K[0, 2]
    v = K[1, 1] * p_cam[1] / p_cam[2] + K[1, 2]
    return int(round(u)), int(round(v))


def project_base_pose_to_image(
    K: np.ndarray,
    T_cam_to_base: np.ndarray,
    pose6_base: np.ndarray,
) -> tuple[int, int] | None:
    """Project the position part of a base-frame pose6 to image pixel."""
    return project_base_point_to_image(K, T_cam_to_base, pose6_base[:3])


def is_point_in_expanded_roi(
    u: int,
    v: int,
    roi: tuple[int, int, int, int],
    margin: int = 50,
) -> bool:
    """Check if pixel (u, v) is inside the ROI expanded by *margin* pixels."""
    x1, y1, x2, y2 = roi
    return (x1 - margin <= u <= x2 + margin and
            y1 - margin <= v <= y2 + margin)


def pixel_distance(
    uv_a: tuple[int, int],
    uv_b: tuple[int, int],
) -> float:
    """Euclidean distance between two pixel coordinates."""
    return float(np.hypot(uv_a[0] - uv_b[0], uv_a[1] - uv_b[1]))


# -- Waypoint parsing ---------------------------------------------------------

def parse_waypoints(path: str) -> dict[str, np.ndarray]:
    """Parse waypoints from 起点终点.txt format.

    Expected format (one header line, then data rows)::

        x mm, y mm, z mm, rx rad, ry rad, rz rad,
        -364.95,-47.02,197.19,0.097,3.162,0.065,起点位置
        -435.35,-179.40,320.39,0.097,3.162,0.065,中间位置
        -290，-428，197，0.243，-3.116，0.154, 放置位置

    Chinese full-width commas (，) are normalised to ASCII commas.
    Positions are converted from mm to metres.

    Returns a dict with keys ``'start'``, ``'middle'``, ``'place'``,
    each mapping to a pose6 array ``[x_m, y_m, z_m, rx, ry, rz]``.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"Waypoint file not found: {path}")

    result: dict[str, np.ndarray] = {}
    label_map = {
        "起点": "start",
        "中间": "middle",
        "放置": "place",
    }

    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    for line_no, raw_line in enumerate(lines, 1):
        line = raw_line.strip()
        if not line:
            continue
        line = line.replace("\uff0c", ",")

        if any(kw in line.lower() for kw in ("x mm", "x_mm", "header")):
            continue

        parts = [p.strip() for p in line.split(",") if p.strip()]
        if len(parts) < 6:
            continue

        try:
            vals = [float(parts[i]) for i in range(6)]
        except ValueError:
            continue

        label_text = " ".join(parts[6:]) if len(parts) > 6 else ""
        matched_key = None
        for cn_key, en_key in label_map.items():
            if cn_key in label_text:
                matched_key = en_key
                break

        if matched_key is None:
            logging.warning("Line %d: unrecognised label '%s', skipping",
                            line_no, label_text)
            continue

        pose6 = np.array([
            vals[0] / 1000.0,
            vals[1] / 1000.0,
            vals[2] / 1000.0,
            vals[3],
            vals[4],
            vals[5],
        ], dtype=np.float64)
        result[matched_key] = pose6
        logging.info("Waypoint '%s': %s", matched_key, pose6)

    for required in ("start", "middle", "place"):
        if required not in result:
            raise ValueError(
                f"Missing waypoint '{required}' in {path}. "
                f"Found: {list(result.keys())}"
            )

    return result


# -- Draw helpers for flange overlay -------------------------------------------

def draw_flange_on_image(
    vis_bgr: np.ndarray,
    K: np.ndarray,
    T_cam_to_base: np.ndarray,
    flange_pose6_base: np.ndarray,
) -> tuple[int, int] | None:
    """Draw the arm flange position and orientation axes on a BGR image.

    Returns the pixel (u, v) if drawn, else None.
    """
    uv = project_base_pose_to_image(K, T_cam_to_base, flange_pose6_base)
    if uv is None:
        return None
    u, v = uv
    h, w = vis_bgr.shape[:2]
    if not (0 <= u < w and 0 <= v < h):
        return None

    cv2.circle(vis_bgr, (u, v), 6, (255, 128, 0), 2, cv2.LINE_AA)
    cv2.putText(vis_bgr, "flange", (u + 8, max(14, v - 6)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 128, 0), 1,
                cv2.LINE_AA)

    T_base_to_cam = np.linalg.inv(T_cam_to_base)
    pose4 = pose6_to_pose4x4(flange_pose6_base)
    pose_cam = T_base_to_cam @ pose4
    origin = pose_cam[:3, 3]

    axis_len = 0.05
    for ax_idx, color in enumerate([(0, 0, 255), (0, 255, 0), (255, 0, 0)]):
        tip = origin + pose_cam[:3, ax_idx] * axis_len
        if tip[2] <= 1e-4:
            continue
        tu = int(K[0, 0] * tip[0] / tip[2] + K[0, 2])
        tv = int(K[1, 1] * tip[1] / tip[2] + K[1, 2])
        if 0 <= tu < w and 0 <= tv < h:
            cv2.line(vis_bgr, (u, v), (tu, tv), color, 2, cv2.LINE_AA)

    return (u, v)


# -- Independent entry point ---------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Test coordinate transforms and waypoint parsing",
    )
    code_dir = os.path.dirname(os.path.realpath(__file__))
    parser.add_argument(
        "--calib", type=str,
        default=os.path.join(code_dir, "手眼标定的旋转矩阵.txt"),
        help="Path to T_cam_to_base calibration file",
    )
    parser.add_argument(
        "--waypoints", type=str,
        default=os.path.join(code_dir, "起点终点.txt"),
        help="Path to waypoints file",
    )
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO,
                        format="%(levelname)s %(message)s")

    print("=" * 60)
    print("Coordinate Transform Test")
    print("=" * 60)

    if os.path.isfile(args.calib):
        T = load_calibration(args.calib)
        print(f"\nT_cam_to_base:\n{T}")

        T_inv = np.linalg.inv(T)
        print(f"\nT_base_to_cam (inverse):\n{T_inv}")

        test_point_cam = np.array([0.0, 0.0, 0.5, 1.0])
        test_point_base = T @ test_point_cam
        print(f"\nTest: camera origin at z=0.5m -> base: {test_point_base[:3]}")
    else:
        print(f"\n[WARN] Calibration file not found: {args.calib}")

    print()

    if os.path.isfile(args.waypoints):
        wp = parse_waypoints(args.waypoints)
        print("Waypoints (metres, radians):")
        for name, pose6 in wp.items():
            print(f"  {name:8s}: pos=[{pose6[0]:.4f}, {pose6[1]:.4f}, "
                  f"{pose6[2]:.4f}]  rot=[{pose6[3]:.3f}, {pose6[4]:.3f}, "
                  f"{pose6[5]:.3f}]")

        print("\n4x4 pose matrices:")
        for name, pose6 in wp.items():
            print(f"\n  {name}:")
            T4 = pose6_to_pose4x4(pose6)
            for row in T4:
                print(f"    [{row[0]:8.5f} {row[1]:8.5f} "
                      f"{row[2]:8.5f} {row[3]:8.5f}]")
    else:
        print(f"[WARN] Waypoints file not found: {args.waypoints}")

    print("\n" + "=" * 60)
    print("Test complete")
    print("=" * 60)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
