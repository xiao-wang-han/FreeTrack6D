"""
UR5 robot arm controller with arrival detection and waypoint management.

"""

from __future__ import annotations

import argparse
import enum
import logging
import os
import socket
import sys
import time

import threading

import cv2
import numpy as np

from coordinate_transform import parse_waypoints, pose6_to_pose4x4


# -- Low-level UR TCP client ---------------------------------------------------

class URRobotTCP:
    """UR5 TCP socket client for sending ``movel`` commands.

    Args:
        host: UR5 controller IP address.
        port: UR5 real-time port (default 30003).
        joint_acc: base acceleration for movel (rad/s^2).
        joint_vel: base velocity for movel (rad/s).
    """

    def __init__(
        self,
        host: str,
        port: int = 30003,
        joint_acc: float = 0.2,
        joint_vel: float = 0.25,
    ):
        self.host = host
        self.port = port
        self.joint_acc = joint_acc
        self.joint_vel = joint_vel
        self._sock: socket.socket | None = None

    @property
    def connected(self) -> bool:
        return self._sock is not None

    def connect(self, timeout_sec: float = 10.0) -> bool:
        """Open the TCP connection to the UR controller."""
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.settimeout(timeout_sec)
        try:
            logging.info("Connecting to UR %s:%d ...", self.host, self.port)
            self._sock.connect((self.host, self.port))
            self._sock.settimeout(None)
            logging.info("UR TCP connected")
            return True
        except (OSError, socket.timeout) as e:
            logging.error("UR connect failed: %s", e)
            try:
                self._sock.close()
            except OSError:
                pass
            self._sock = None
            return False

    def close(self):
        """Close the TCP connection."""
        if self._sock:
            try:
                self._sock.close()
            except OSError:
                pass
            self._sock = None

    def movel_pose(
        self,
        pose6: np.ndarray,
        k_acc: float = 1.0,
        k_vel: float = 1.0,
        t: float = 0,
        r: float = 0.01,
    ):
        """Send a ``movel(p[...])`` command to the UR controller.

        Args:
            pose6: [x, y, z, rx, ry, rz] in metres and radians.
            k_acc: acceleration multiplier.
            k_vel: velocity multiplier.
            t: time (s), 0 lets the controller decide duration.
            r: blend radius (m).
        """
        if not self._sock:
            raise RuntimeError("Socket not connected")
        a = k_acc * self.joint_acc
        v = k_vel * self.joint_vel
        p = pose6.astype(float)
        cmd = (
            f"movel(p[{p[0]:.6f},{p[1]:.6f},{p[2]:.6f},"
            f"{p[3]:.6f},{p[4]:.6f},{p[5]:.6f}],a={a:g},v={v:g},t={t:g},r={r:g})\n"
        )
        self._sock.sendall(cmd.encode("utf-8"))
        logging.info("UR> %s", cmd.strip())


# -- RTDE helper ---------------------------------------------------------------

def _try_connect_rtde(host: str):
    """Attempt to connect to RTDE for real-time joint/TCP reading.

    Returns the interface object or None if unavailable.
    """
    try:
        import rtde_receive
        iface = rtde_receive.RTDEReceiveInterface(host)
        logging.info("RTDE connected to %s", host)
        return iface
    except ImportError:
        logging.warning(
            "ur_rtde not installed — arrival detection will use timer. "
            "Install: pip install ur-rtde"
        )
        return None
    except Exception as e:
        logging.warning("RTDE connection failed: %s", e)
        return None


# -- Move phase enum -----------------------------------------------------------

class MovePhase(enum.Enum):
    IDLE = "idle"
    TO_MIDDLE = "to_middle"
    TO_START = "to_start"
    TO_PLACE = "to_place"
    TO_TARGET = "to_target"


# -- High-level arm controller -------------------------------------------------

class ArmController:
    """High-level UR5 arm controller with waypoint management.

    Args:
        ur: connected URRobotTCP instance.
        waypoints: dict with 'start', 'middle', 'place' pose6 arrays.
        gripper: optional DH_gripper instance (None to disable).
        gripper_open_pos: gripper open position in 0.1mm units (950 = 95mm).
        gripper_close_pos: gripper close position in 0.1mm units (500 = 50mm).
        pos_tolerance: position arrival tolerance in metres.
        rot_tolerance: rotation arrival tolerance in radians.
        settle_time: fallback timer for arrival (seconds) when RTDE
            is unavailable.
        k_acc: movel acceleration scale factor.
        k_vel: movel velocity scale factor.
    """

    def __init__(
        self,
        ur: URRobotTCP,
        waypoints: dict[str, np.ndarray],
        rtde_iface=None,
        gripper=None,
        gripper_open_pos: int = 950,
        gripper_close_pos: int = 500,
        pos_tolerance: float = 0.02,
        rot_tolerance: float = 0.1,
        settle_time: float = 4.0,
        k_acc: float = 1.0,
        k_vel: float = 1.0,
        target_update_interval: float = 0.2,
        target_pos_threshold: float = 0.005,
        target_rot_threshold: float = 0.035,
    ):
        self.ur = ur
        self.waypoints = waypoints
        self.rtde = rtde_iface
        self.gripper = gripper
        self.gripper_open_pos = gripper_open_pos
        self.gripper_close_pos = gripper_close_pos
        self.pos_tolerance = pos_tolerance
        self.rot_tolerance = rot_tolerance
        self.settle_time = settle_time
        self.k_acc = k_acc
        self.k_vel = k_vel

        self.target_update_interval = target_update_interval
        self.target_pos_threshold = target_pos_threshold
        self.target_rot_threshold = target_rot_threshold

        self.move_phase = MovePhase.IDLE
        self._last_target: np.ndarray | None = None
        self._last_target_send_time: float = 0.0

        # 在 ArmController.__init__ 末尾添加
        self._servo_active = False          # 实时模式开关
        self._servo_thread = None           # 后台线程句柄
        self._servo_alpha = 0.001            # 低通滤波系数 (0.01~0.1)
        self._servo_current_pose = None     # 内部平滑插值位姿

    @property
    def is_moving(self) -> bool:
        return self.move_phase != MovePhase.IDLE

    def get_tcp_pose(self) -> np.ndarray | None:
        """Read current TCP pose [x, y, z, rx, ry, rz] via RTDE.

        Returns None if RTDE is unavailable.
        """
        if self.rtde is None:
            return None
        try:
            return np.asarray(
                self.rtde.getActualTCPPose(), dtype=np.float64,
            )
        except Exception:
            return None

    def check_arrival(
        self,
        target_pose6: np.ndarray,
    ) -> bool:
        """Check if the arm has arrived at the target using RTDE.

        Returns True if within tolerance, False otherwise.
        Always returns False if RTDE is unavailable (use timer fallback).
        """
        current = self.get_tcp_pose()
        if current is None:
            return False
        pos_err = float(np.linalg.norm(current[:3] - target_pose6[:3]))
        R_cur, _ = cv2.Rodrigues(current[3:6].astype(np.float64))
        R_tgt, _ = cv2.Rodrigues(target_pose6[3:6].astype(np.float64))
        dR = R_cur.T @ R_tgt
        cos_angle = (np.trace(dR) - 1.0) / 2.0
        cos_angle = np.clip(cos_angle, -1.0, 1.0)
        rot_err = float(np.arccos(cos_angle))
        return pos_err < self.pos_tolerance and rot_err < self.rot_tolerance

    _MOVE_TIMEOUT = 15.0

    def _move_and_wait(
        self,
        target: np.ndarray,
        phase: MovePhase,
        timeout: float | None = None,
    ) -> bool:
        """Send movel and block until RTDE confirms arrival.

        Uses ``pos_tolerance`` and ``rot_tolerance`` for the 6D check.
        Sends with ``r=0.01`` (1cm blend radius); ``pos_tolerance``
        must be >= blend radius so arrival is detected inside the
        blend zone.  If RTDE is unavailable, ``settle_time`` is used
        as a timed fallback.
        """
        self.move_phase = phase
        self._last_target = target.copy()
        self.ur.movel_pose(target, k_acc=self.k_acc, k_vel=self.k_vel, r=0.01)

        if self.rtde is None:
            if self.settle_time > 0:
                logging.warning(
                    "%s: RTDE unavailable — fallback sleep %.1fs",
                    phase.value, self.settle_time,
                )
                time.sleep(self.settle_time)
            else:
                logging.warning(
                    "%s: RTDE unavailable, settle_time=0 — no wait",
                    phase.value,
                )
            return True

        t_start = time.time()
        max_wait = timeout or self._MOVE_TIMEOUT
        while time.time() - t_start < max_wait:
            if self.check_arrival(target):
                elapsed = time.time() - t_start
                logging.info("%s arrived (RTDE, %.2fs, pos_tol=%.3f, "
                             "rot_tol=%.3f)",
                             phase.value, elapsed,
                             self.pos_tolerance, self.rot_tolerance)
                return True
            time.sleep(0.05)
        logging.warning("%s RTDE timeout (%.1fs) — continuing",
                        phase.value, max_wait)
        return True

    def go_to_start(self) -> bool:
        """Move: current -> middle -> start (with arrival detection).

        Opens gripper to 95mm after reaching start position.
        """
        logging.info("go_to_start: middle -> start")
        ok = self._move_and_wait(self.waypoints["middle"], MovePhase.TO_MIDDLE)
        if not ok:
            return False
        ok = self._move_and_wait(self.waypoints["start"], MovePhase.TO_START)
        self.gripper_open()
        self.move_phase = MovePhase.IDLE
        return ok

    def go_to_place(self) -> bool:
        """Move: current -> middle -> place (with arrival detection)."""
        logging.info("go_to_place: middle -> place")
        ok = self._move_and_wait(self.waypoints["middle"], MovePhase.TO_MIDDLE)
        if not ok:
            return False
        ok = self._move_and_wait(self.waypoints["place"], MovePhase.TO_PLACE)
        self.move_phase = MovePhase.IDLE
        return ok

    def go_to_middle(self) -> bool:
        """Move to the middle (intermediate) waypoint."""
        logging.info("go_to_middle")
        ok = self._move_and_wait(self.waypoints["middle"], MovePhase.TO_MIDDLE)
        self.move_phase = MovePhase.IDLE
        return ok

    # def send_to_target(self, pose6: np.ndarray):
    #     """Send movel to a target without blocking (for live updates).

    #     Applies rate-limiting and threshold-gating to avoid flooding the
    #     UR controller with movel commands (which cause stop-restart jitter).
    #     A new movel is only sent when BOTH conditions are met:
    #       1. At least ``target_update_interval`` seconds since last send.
    #       2. Position or rotation has changed beyond the dead-zone thresholds.

    #     Does NOT wait for arrival — caller manages the tracking loop.
    #     """
    #     now = time.time()
    #     dt = now - self._last_target_send_time

    #     if dt < self.target_update_interval:
    #         return

    #     if self._last_target is not None:
    #         pos_delta = float(np.linalg.norm(pose6[:3] - self._last_target[:3]))
    #         rot_delta = float(np.linalg.norm(pose6[3:6] - self._last_target[3:6]))
    #         if pos_delta < self.target_pos_threshold and rot_delta < self.target_rot_threshold:
    #             return

    #     self.move_phase = MovePhase.TO_TARGET
    #     self._last_target = pose6.copy()
    #     self._last_target_send_time = now
    #     self.ur.movel_pose(pose6, k_acc=self.k_acc, k_vel=self.k_vel, r=0)
    def send_to_target(self, pose6: np.ndarray):
        now = time.time()
        dt = now - self._last_target_send_time

        # 保留原有的频率限制和死区过滤逻辑
        if dt < self.target_update_interval:
            return

        if self._last_target is not None:
            pos_delta = float(np.linalg.norm(pose6[:3] - self._last_target[:3]))
            rot_delta = float(np.linalg.norm(pose6[3:6] - self._last_target[3:6]))
            if pos_delta < self.target_pos_threshold and rot_delta < self.target_rot_threshold:
                return

        # 更新目标
        self.move_phase = MovePhase.TO_TARGET
        self._last_target = pose6.copy()
        self._last_target_send_time = now

        # 模式分支
        if not getattr(self, '_servo_active', False):
            # 兼容模式：传统 movel (会导致停顿)
            self.ur.movel_pose(pose6, k_acc=self.k_acc, k_vel=self.k_vel, r=0)
        # 如果 servo_active 为 True，后台线程会自动读取新的 self._last_target 并平滑执行


    # -- Gripper helpers -------------------------------------------------------

    def gripper_open(self):
        """Open the gripper to the configured open position."""
        if self.gripper is None:
            return
        logging.info("Gripper open -> %d (%.1fmm)",
                    self.gripper_open_pos, self.gripper_open_pos / 10.0)
        self.gripper.SetTargetPosition(self.gripper_open_pos)
        self._wait_gripper()

    def gripper_close(self):
        """Close the gripper to the configured close position."""
        if self.gripper is None:
            return
        logging.info("Gripper close -> %d (%.1fmm)",
                    self.gripper_close_pos, self.gripper_close_pos / 10.0)
        self.gripper.SetTargetPosition(self.gripper_close_pos)
        self._wait_gripper()

    def _wait_gripper(self, timeout: float = 8.0, settle: float = 0.5):
        """Wait for the gripper to finish its motion.

        Polls ``GetGripState`` until non-zero (1 = reached target,
        2 = grip detected).  After detection, waits an additional
        *settle* seconds for mechanical settling.  If the state poll
        times out, falls back to a fixed 2s wait.
        """
        if self.gripper is None:
            return
        t0 = time.time()
        errors = 0
        while time.time() - t0 < timeout:
            try:
                state = self.gripper.GetGripState()
                if state != 0:
                    logging.info("Gripper state=%d after %.1fs, settling %.1fs",
                                state, time.time() - t0, settle)
                    time.sleep(settle)
                    return
            except Exception as e:
                errors += 1
                if errors <= 3:
                    logging.debug("GetGripState error: %s", e)
            time.sleep(0.1)
        logging.warning("Gripper motion timeout (%.1fs, %d errors) — "
                        "fallback wait 2s", timeout, errors)
        time.sleep(2.0)

    # -- Descend helper --------------------------------------------------------

    def descend(self, offset_m: float = 0.10) -> bool:
        """Move straight down by *offset_m* metres from the last target.

        Copies the last target pose and subtracts *offset_m* from the
        Z coordinate (base frame, Z-up convention).
        """
        if self._last_target is None:
            logging.warning("descend: no last target")
            return False
        target = self._last_target.copy()
        target[2] -= offset_m
        return self._move_and_wait(target, MovePhase.TO_TARGET)

    # -- Full grab-and-place sequences -----------------------------------------

    def go_grab_and_place(self) -> bool:
        """Complete pick-place cycle (called from ArmThread).

        Assumes the arm is already at the predicted target position
        (with safety offset above the workpiece).

        Steps:
        1. Descend 14cm toward the workpiece
        2. Close gripper (50mm)
        3. Middle -> place
        4. Open gripper (95mm)
        5. Middle -> start
        """
        logging.info("go_grab_and_place: descend + grip + place + home")

        # 1. descend
        self.descend(0.14)

        # 2. close gripper
        self.gripper_close()

        # 3. go to place (middle -> place)
        ok = self._move_and_wait(self.waypoints["middle"], MovePhase.TO_MIDDLE)
        if not ok:
            return False
        ok = self._move_and_wait(self.waypoints["place"], MovePhase.TO_PLACE)
        if not ok:
            return False

        # 4. open gripper
        self.gripper_open()

        # 5. go home (middle -> start)
        ok = self._move_and_wait(self.waypoints["middle"], MovePhase.TO_MIDDLE)
        if not ok:
            return False
        ok = self._move_and_wait(self.waypoints["start"], MovePhase.TO_START)
        self.move_phase = MovePhase.IDLE
        return ok

    def go_pick_and_place(self, target_pose6: np.ndarray) -> bool:
        """One-shot pick-place: middle -> target -> descend -> grip -> place.

        Unlike ``go_grab_and_place`` (which assumes the arm is already near
        the target), this method executes the FULL path from wherever the
        arm currently is.

        Steps:
        1. Middle waypoint
        2. movel to *target_pose6* (predicted position with safety offset)
        3. Descend 14cm
        4. Close gripper
        5. Middle -> place
        6. Open gripper
        """
        logging.info("go_pick_and_place: middle -> target -> descend "
                    "-> grip -> middle -> place -> release")

        # 1. go to middle
        ok = self._move_and_wait(self.waypoints["middle"], MovePhase.TO_MIDDLE)
        if not ok:
            return False

        # 2. go to predicted target
        ok = self._move_and_wait(target_pose6, MovePhase.TO_TARGET)
        if not ok:
            return False

        # 3. descend 14cm
        self.descend(0.14)

        # 4. close gripper
        self.gripper_close()

        # 5. go to place (middle -> place)
        ok = self._move_and_wait(self.waypoints["middle"], MovePhase.TO_MIDDLE)
        if not ok:
            return False
        ok = self._move_and_wait(self.waypoints["place"], MovePhase.TO_PLACE)
        if not ok:
            return False

        # 6. open gripper
        self.gripper_open()

        self.move_phase = MovePhase.IDLE
        return ok


    # def _servo_loop(self):
    #     """125Hz 实时控制循环，实现从 1-5Hz 到 125Hz 的平滑插值"""
    #     dt = 0.0125
    #     while self._servo_active:
    #         t_start = time.time()
            
    #         # 仅在 Phase 为 TO_TARGET 且有目标时工作
    #         if self.move_phase == MovePhase.TO_TARGET and self._last_target is not None:
    #             if self._servo_current_pose is None:
    #                 self._servo_current_pose = self.get_tcp_pose() or self._last_target.copy()
                
    #             # 一阶低通滤波 (Exponential Smoothing)
    #             # 即使视觉没更新，这里也会每 8ms 让指令位姿向目标靠拢
    #             self._servo_current_pose = (self._servo_alpha * self._last_target + 
    #                                     (1.0 - self._servo_alpha) * self._servo_current_pose)
                
    #             # 发送 servoj 替代 movel
    #             p = self._servo_current_pose
    #             cmd = (f"servoj(get_inverse_kin(p[{p[0]:.6f},{p[1]:.6f},{p[2]:.6f},"
    #                 f"{p[3]:.6f},{p[4]:.6f},{p[5]:.6f}]), "
    #                 f"t=0.2, lookahead_time=0.2, gain=100)\n")
    #             try:
    #                 self.ur._sock.sendall(cmd.encode("utf-8"))
    #             except Exception:
    #                 break
                    
    #         # 维持 125Hz 频率
    #         elapsed = time.time() - t_start
    #         if elapsed < dt:
    #             time.sleep(dt - elapsed)

    def _servo_loop(self):
        """125Hz 实时控制循环，包含速度与加速度限制"""
        dt = 0.008  # UR5 建议 125Hz 使用 0.008s
        
        # 定义物理约束
        MAX_VEL = 0.2     # m/s
        MAX_ACC = 0.1     # m/s^2
        
        # 计算每帧允许的最大增量
        # v = v0 + a*dt -> 每一帧能改变的最大速度增量
        # d_pos = v*dt  -> 每一帧能移动的最大位置增量
        max_step_dist = MAX_VEL * dt 
        
        # 初始化上一帧速度用于加速度控制（可选简化处理，主要控速）
        last_step_vel = 0.0

        while self._servo_active:
            t_start = time.time()
            
            if self.move_phase == MovePhase.TO_TARGET and self._last_target is not None:
                if self._servo_current_pose is None:
                    self._servo_current_pose = self.get_tcp_pose() or self._last_target.copy()
                
                # 1. 计算期望的目标增量 (滤波后的)
                # target_step 是滤波后下一步应该去的位置
                target_filtered = (self._servo_alpha * self._last_target + 
                                   (1.0 - self._servo_alpha) * self._servo_current_pose)
                
                # 2. 速度与位置步长限制 (限速 0.2m/s)
                diff = target_filtered[:3] - self._servo_current_pose[:3]
                dist = np.linalg.norm(diff)
                
                if dist > max_step_dist:
                    # 如果移动距离超过了 0.2m/s * dt，则强制截断
                    step_vector = (diff / dist) * max_step_dist
                    self._servo_current_pose[:3] += step_vector
                else:
                    self._servo_current_pose[:3] = target_filtered[:3]
                
                # 姿态部分(RX, RY, RZ)直接跟随滤波值，通常姿态跳变不剧烈
                self._servo_current_pose[3:] = target_filtered[3:]
                
                # 3. 发送 servoj
                # 修正参数：t=dt*1.5 (约0.012) 保证连续；lookahead 调小以减少滞后
                p = self._servo_current_pose
                cmd = (f"servoj(get_inverse_kin(p[{p[0]:.6f},{p[1]:.6f},{p[2]:.6f},"
                       f"{p[3]:.6f},{p[4]:.6f},{p[5]:.6f}]), "
                       f"t=0.4, lookahead_time=0.02, gain=100)\n")
                
                try:
                    self.ur._sock.sendall(cmd.encode("utf-8"))
                except Exception:
                    break
                    
            elapsed = time.time() - t_start
            if elapsed < dt:
                time.sleep(dt - elapsed)

    def set_tracking_mode(self, enable: bool, alpha: float = 0.05):
        """外部开关：开启或关闭实时平滑追踪"""
        self._servo_alpha = alpha
        if enable and not self._servo_active:
            self._servo_active = True
            self._servo_current_pose = self.get_tcp_pose()
            self._servo_thread = threading.Thread(target=self._servo_loop, daemon=True)
            self._servo_thread.start()
            logging.info("Servo tracking mode ENABLED")
        elif not enable and self._servo_active:
            self._servo_active = False
            if self._servo_thread:
                self._servo_thread.join(timeout=1.0)
            logging.info("Servo tracking mode DISABLED")


# -- Independent entry point ---------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="UR5 arm controller — independent test entry point",
    )
    code_dir = os.path.dirname(os.path.realpath(__file__))

    parser.add_argument("--ur_host", type=str, default="192.168.100.10")
    parser.add_argument("--ur_port", type=int, default=30003)
    parser.add_argument("--ur_acc", type=float, default=0.5)
    parser.add_argument("--ur_vel", type=float, default=0.2)
    parser.add_argument("--k_acc", type=float, default=1.0)
    parser.add_argument("--k_vel", type=float, default=1.0)
    parser.add_argument("--settle_time", type=float, default=4.0)
    parser.add_argument(
        "--waypoints", type=str,
        default=os.path.join(code_dir, "起点终点.txt"),
    )

    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--test_waypoints", action="store_true",
                      help="Test: middle -> start, middle -> place")
    mode.add_argument("--test_home", action="store_true",
                      help="Test: go to start position")
    mode.add_argument("--test_place", action="store_true",
                      help="Test: go to place position")
    mode.add_argument("--test_read", action="store_true",
                      help="Read and display current TCP pose via RTDE")
    mode.add_argument("--dry_run", action="store_true",
                      help="Parse waypoints and print without connecting")

    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO,
                        format="%(levelname)s %(message)s")

    wp = parse_waypoints(args.waypoints)
    print(f"Waypoints loaded: {list(wp.keys())}")
    for name, pose6 in wp.items():
        print(f"  {name:8s}: [{pose6[0]:.4f}, {pose6[1]:.4f}, "
              f"{pose6[2]:.4f}, {pose6[3]:.3f}, {pose6[4]:.3f}, "
              f"{pose6[5]:.3f}]")

    if args.dry_run:
        print("\n[DRY RUN] No robot connection — exiting.")
        return 0

    ur = URRobotTCP(args.ur_host, args.ur_port, args.ur_acc, args.ur_vel)
    if not ur.connect():
        return 1

    rtde = _try_connect_rtde(args.ur_host)

    controller = ArmController(
        ur, wp, rtde_iface=rtde,
        settle_time=args.settle_time,
        k_acc=args.k_acc, k_vel=args.k_vel,
    )

    try:
        if args.test_read:
            tcp = controller.get_tcp_pose()
            if tcp is not None:
                print(f"Current TCP pose: {tcp}")
            else:
                print("[WARN] RTDE unavailable — cannot read TCP pose")
            return 0

        if args.test_home or args.test_waypoints:
            print("\n--- Go to START ---")
            controller.go_to_start()

        if args.test_place or args.test_waypoints:
            print("\n--- Go to PLACE ---")
            controller.go_to_place()

        if args.test_waypoints:
            print("\n--- Return to START ---")
            controller.go_to_start()

        print("\nTest complete.")
    finally:
        ur.close()
        if rtde is not None:
            try:
                rtde.disconnect()
            except Exception:
                pass

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
