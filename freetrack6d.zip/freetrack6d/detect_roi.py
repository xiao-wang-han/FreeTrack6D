"""
Hand-drawn ROI selector for conveyor-belt region.


"""

from __future__ import annotations

import argparse
import glob
import json
import os

import cv2
import numpy as np


# -- ROI config I/O -----------------------------------------------------------

def load_roi_config(path: str) -> tuple[int, int, int, int] | None:
    """Load ROI rectangle from JSON.

    Returns ``(x1, y1, x2, y2)`` or ``None`` when the file is missing,
    unreadable, or contains no valid ROI coordinates.
    """
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r") as f:
            d = json.load(f)
    except (json.JSONDecodeError, OSError):
        return None
    if "x1" in d and "y1" in d and "x2" in d and "y2" in d:
        return int(d["x1"]), int(d["y1"]), int(d["x2"]), int(d["y2"])
    return None


def save_roi_config(path: str, x1: int, y1: int, x2: int, y2: int):
    """Save ROI to JSON, preserving any existing mask_params in the file."""
    existing = {}
    if os.path.exists(path):
        try:
            with open(path, "r") as f:
                existing = json.load(f)
            if not isinstance(existing, dict):
                existing = {}
        except (json.JSONDecodeError, OSError):
            existing = {}
    existing.update({"x1": x1, "y1": y1, "x2": x2, "y2": y2})
    with open(path, "w", newline="\n") as f:
        json.dump(existing, f, indent=2)
        f.write("\n")
    print(f"ROI saved to {path}: ({x1}, {y1}, {x2}, {y2})")


def load_mask_params(path: str) -> dict | None:
    """Load mask tuning parameters from the ``mask_params`` section of a
    roi_config.json file.  Returns ``None`` if not present."""
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r") as f:
            d = json.load(f)
    except (json.JSONDecodeError, OSError):
        return None
    mp = d.get("mask_params")
    if isinstance(mp, dict):
        return mp
    return None


def save_mask_params(path: str, params: dict):
    """Merge mask tuning parameters into an existing roi_config.json."""
    existing = {}
    if os.path.exists(path):
        try:
            with open(path, "r") as f:
                existing = json.load(f)
            if not isinstance(existing, dict):
                existing = {}
        except (json.JSONDecodeError, OSError):
            existing = {}
    existing["mask_params"] = params
    with open(path, "w", newline="\n") as f:
        json.dump(existing, f, indent=2)
        f.write("\n")
    print(f"Mask params saved to {path}: {params}")


# -- Interactive selector ------------------------------------------------------

class _RoiSelector:
    def __init__(self, img_bgr: np.ndarray):
        self.img = img_bgr.copy()
        self.drawing = False
        self.x1 = self.y1 = self.x2 = self.y2 = -1
        self.done = False

    def mouse_cb(self, event, x, y, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN:
            self.drawing = True
            self.x1, self.y1 = x, y
            self.x2, self.y2 = x, y
        elif event == cv2.EVENT_MOUSEMOVE and self.drawing:
            self.x2, self.y2 = x, y
        elif event == cv2.EVENT_LBUTTONUP:
            self.drawing = False
            self.x2, self.y2 = x, y

    @property
    def has_rect(self) -> bool:
        return self.x1 >= 0 and self.x2 >= 0 and self.x1 != self.x2

    def normalised(self) -> tuple[int, int, int, int]:
        return (
            min(self.x1, self.x2),
            min(self.y1, self.y2),
            max(self.x1, self.x2),
            max(self.y1, self.y2),
        )


def select_roi_interactive(
    img_bgr: np.ndarray,
    existing_roi: tuple[int, int, int, int] | None = None,
    window_name: str = "Draw ROI (drag mouse, Enter=save, r=reset, Esc=quit)",
) -> tuple[int, int, int, int] | None:
    """Show *img_bgr* and let user draw a rectangle.

    Returns ``(x1, y1, x2, y2)`` or ``None`` if cancelled.
    """
    sel = _RoiSelector(img_bgr)

    if existing_roi is not None:
        sel.x1, sel.y1, sel.x2, sel.y2 = existing_roi

    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.setMouseCallback(window_name, sel.mouse_cb)

    while True:
        vis = sel.img.copy()

        if sel.has_rect:
            rx1, ry1, rx2, ry2 = sel.normalised()
            cv2.rectangle(vis, (rx1, ry1), (rx2, ry2), (0, 255, 0), 2)
            label = f"ROI: ({rx1},{ry1})-({rx2},{ry2})  {rx2-rx1}x{ry2-ry1}"
            cv2.putText(vis, label, (rx1, ry1 - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 0), 1,
                        cv2.LINE_AA)

        help_lines = [
            "Drag mouse: draw ROI",
            "r: reset   Enter/Space: save   Esc/q: quit",
        ]
        for i, line in enumerate(help_lines):
            cv2.putText(vis, line, (10, 22 + i * 22),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.50, (255, 255, 255), 1,
                        cv2.LINE_AA)

        cv2.imshow(window_name, vis)
        key = cv2.waitKey(30) & 0xFF

        if key in (13, 32):  # Enter / Space
            if sel.has_rect:
                cv2.destroyWindow(window_name)
                return sel.normalised()
        elif key == ord("r"):
            sel.x1 = sel.y1 = sel.x2 = sel.y2 = -1
        elif key in (27, ord("q")):  # Esc / q
            cv2.destroyWindow(window_name)
            return None


# -- Live camera selector -----------------------------------------------------

def select_roi_from_camera(
    existing_roi: tuple[int, int, int, int] | None = None,
    window_name: str = "Draw ROI on LIVE camera (c=freeze, r=reset, Enter=save, Esc=quit)",
    cam_width: int = 1280,
    cam_height: int = 720,
    cam_fps: int = 30,
) -> tuple[int, int, int, int] | None:
    """Open RealSense camera, show live video, let user draw ROI.

    Press **c** to freeze/unfreeze the frame (easier to draw precisely).
    Returns ``(x1, y1, x2, y2)`` or ``None`` if cancelled.
    """
    try:
        import pyrealsense2 as rs
    except ImportError:
        print("[ERROR] pyrealsense2 not installed. "
              "Run: pip install pyrealsense2")
        return None

    ctx = rs.context()
    if len(ctx.query_devices()) == 0:
        print("[ERROR] No RealSense device found.")
        return None

    pipeline = rs.pipeline()
    config = rs.config()
    config.enable_stream(rs.stream.color, cam_width, cam_height,
                         rs.format.bgr8, cam_fps)
    try:
        pipeline.start(config)
    except Exception as e:
        print(f"[ERROR] Cannot start camera: {e}")
        return None

    print(f"Camera opened: {cam_width}x{cam_height}@{cam_fps}fps")
    print("Controls:")
    print("  Mouse drag  -- draw ROI rectangle")
    print("  c           -- freeze / unfreeze frame")
    print("  r           -- reset rectangle")
    print("  Enter/Space -- confirm and save")
    print("  Esc/q       -- quit without saving")

    sel = _RoiSelector(np.zeros((cam_height, cam_width, 3), dtype=np.uint8))
    if existing_roi is not None:
        sel.x1, sel.y1, sel.x2, sel.y2 = existing_roi

    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.setMouseCallback(window_name, sel.mouse_cb)

    frozen = False
    frozen_frame = None

    try:
        while True:
            if not frozen:
                frames = pipeline.wait_for_frames(timeout_ms=3000)
                color_frame = frames.get_color_frame()
                if color_frame:
                    live = np.asanyarray(color_frame.get_data())
                    sel.img = live.copy()
                    frozen_frame = live.copy()

            vis = (frozen_frame if frozen_frame is not None
                   else sel.img).copy()

            if sel.has_rect:
                rx1, ry1, rx2, ry2 = sel.normalised()
                cv2.rectangle(vis, (rx1, ry1), (rx2, ry2), (0, 255, 0), 2)
                label = f"ROI: ({rx1},{ry1})-({rx2},{ry2})  {rx2-rx1}x{ry2-ry1}"
                cv2.putText(vis, label, (rx1, ry1 - 8),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 0), 1,
                            cv2.LINE_AA)

            help_lines = [
                "[LIVE]  Drag: draw ROI   c: freeze/unfreeze",
                "r: reset   Enter/Space: save   Esc/q: quit",
            ]
            if frozen:
                help_lines[0] = "[FROZEN]  Drag: draw ROI   c: unfreeze"

            for i, line in enumerate(help_lines):
                cv2.putText(vis, line, (10, 22 + i * 22),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.50,
                            (255, 255, 255), 1, cv2.LINE_AA)

            cv2.imshow(window_name, vis)
            key = cv2.waitKey(30) & 0xFF

            if key in (13, 32):  # Enter / Space
                if sel.has_rect:
                    cv2.destroyWindow(window_name)
                    return sel.normalised()
            elif key == ord("c"):
                frozen = not frozen
                if frozen:
                    print("Frame frozen -- draw your ROI, then Enter to save")
                else:
                    print("Frame unfrozen -- showing live video")
            elif key == ord("r"):
                sel.x1 = sel.y1 = sel.x2 = sel.y2 = -1
            elif key in (27, ord("q")):
                cv2.destroyWindow(window_name)
                return None
    finally:
        pipeline.stop()


# -- CLI -----------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Interactively select conveyor-belt ROI (file or camera)"
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--scene_dir", type=str, default=None,
        help="Scene directory containing rgb/ subfolder (file mode)",
    )
    group.add_argument(
        "--camera", action="store_true", default=False,
        help="Use live RealSense camera feed instead of files",
    )
    parser.add_argument(
        "--output", type=str, default=None,
        help="Output JSON path (default: {scene_dir}/roi_config.json "
             "or ./roi_config.json for camera mode)",
    )
    parser.add_argument("--cam_width", type=int, default=1280)
    parser.add_argument("--cam_height", type=int, default=720)
    parser.add_argument("--cam_fps", type=int, default=30)
    args = parser.parse_args()

    if args.output:
        out_path = args.output
    elif args.scene_dir:
        out_path = os.path.join(args.scene_dir, "roi_config.json")
    else:
        out_path = "roi_config.json"

    existing = load_roi_config(out_path)
    if existing is not None:
        print(f"Existing ROI loaded: {existing}")

    if args.camera:
        roi = select_roi_from_camera(
            existing_roi=existing,
            cam_width=args.cam_width,
            cam_height=args.cam_height,
            cam_fps=args.cam_fps,
        )
    else:
        rgb_files = sorted(glob.glob(
            os.path.join(args.scene_dir, "rgb", "*.png")))
        if not rgb_files:
            print(f"[ERROR] No PNG files in {args.scene_dir}/rgb/")
            return 1

        img = cv2.imread(rgb_files[0])
        if img is None:
            print(f"[ERROR] Cannot read {rgb_files[0]}")
            return 1

        print(f"Image: {rgb_files[0]}  ({img.shape[1]}x{img.shape[0]})")
        roi = select_roi_interactive(img, existing_roi=existing)

    if roi is None:
        print("Cancelled -- no ROI saved.")
        return 0

    save_roi_config(out_path, *roi)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
