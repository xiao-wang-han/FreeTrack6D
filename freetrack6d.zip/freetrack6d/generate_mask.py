"""
Standalone mask generation and debugging tool.


Usage:
  # Interactive with live camera (recommended for deployment tuning)
  python generate_mask.py --camera --interactive

  # Interactive with files
  python generate_mask.py --scene_dir demo_data/888 --interactive

  # Batch: generate and save masks for all frames
  python generate_mask.py --scene_dir demo_data/888 --save

  # With custom parameters
  python generate_mask.py --scene_dir demo_data/888 --save \\
      --fg_offset 25 --silver_s_max 120 --min_area 200 --max_area 50000

Prerequisites:
  Run ``python detect_roi.py --scene_dir demo_data/888`` (or --camera) first
  to create ``roi_config.json``.
"""

from __future__ import annotations

import argparse
import glob
import os
import sys

import cv2
import imageio
import numpy as np

from detect_roi import load_roi_config, load_mask_params, save_mask_params


def compute_mask(
    color_rgb: np.ndarray,
    depth: np.ndarray | None,
    roi: tuple[int, int, int, int] | None,
    fg_offset: int,
    silver_s_max: int,
    min_area: int,
    max_area: int,
    morph_kernel: int,
    depth_min: float,
    depth_max: float,
    bg_gray: np.ndarray | None = None,
    motion_thresh: int = 25,
) -> dict:
    """Core mask computation via local brightness difference.

    Within the ROI, bright (high V-channel) and low-saturation pixels are
    classified as foreground.  Contours with area < *min_area* or > *max_area*
    are rejected.  Returns a dict with the binary mask and debug images.
    """
    H, W = color_rgb.shape[:2]

    x1, y1, x2, y2 = roi if roi else (0, 0, W, H)
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(W, x2), min(H, y2)

    roi_rgb = color_rgb[y1:y2, x1:x2]
    hsv = cv2.cvtColor(roi_rgb, cv2.COLOR_RGB2HSV)
    h_chan = hsv[:, :, 0]
    s_chan = hsv[:, :, 1]
    v_chan = hsv[:, :, 2]

    bg_v_median = int(np.median(v_chan))
    fg_thresh = min(bg_v_median + fg_offset, 254)

    v_mask = (v_chan > fg_thresh).astype(np.uint8) * 255
    s_mask = (s_chan <= silver_s_max).astype(np.uint8) * 255
    color_mask = cv2.bitwise_and(v_mask, s_mask)

    motion_mask = None
    if bg_gray is not None:
        gray = cv2.cvtColor(color_rgb, cv2.COLOR_RGB2GRAY)
        diff = cv2.absdiff(gray[y1:y2, x1:x2], bg_gray[y1:y2, x1:x2])
        _, motion_mask = cv2.threshold(diff, motion_thresh, 255, cv2.THRESH_BINARY)
        color_mask = cv2.bitwise_or(color_mask, motion_mask)

    depth_mask = None
    if depth is not None:
        roi_depth = depth[y1:y2, x1:x2]
        depth_mask = (
            (roi_depth > depth_min) & (roi_depth < depth_max)
        ).astype(np.uint8) * 255
        color_mask = cv2.bitwise_and(color_mask, depth_mask)

    k = max(morph_kernel, 1) | 1  # ensure odd
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    after_morph = cv2.morphologyEx(color_mask, cv2.MORPH_CLOSE, kernel, iterations=2)
    after_morph = cv2.morphologyEx(after_morph, cv2.MORPH_OPEN, kernel, iterations=1)

    contours, _ = cv2.findContours(
        after_morph, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )
    final_roi = np.zeros_like(after_morph)
    kept_contours = []
    rejected_contours = []
    for c in contours:
        area = cv2.contourArea(c)
        if area < min_area:
            rejected_contours.append((c, area, "too_small"))
        elif max_area > 0 and area > max_area:
            rejected_contours.append((c, area, "too_large"))
        else:
            cv2.drawContours(final_roi, [c], -1, 255, cv2.FILLED)
            kept_contours.append((c, area))

    full_mask = np.zeros((H, W), dtype=np.uint8)
    full_mask[y1:y2, x1:x2] = final_roi

    return {
        "mask": full_mask,
        "roi": (x1, y1, x2, y2),
        "bg_v_median": bg_v_median,
        "fg_thresh": fg_thresh,
        "v_mask": v_mask,
        "s_mask": s_mask,
        "depth_mask": depth_mask,
        "motion_mask": motion_mask,
        "after_morph": after_morph,
        "contours": kept_contours,
        "rejected_contours": rejected_contours,
        "h_chan": h_chan,
        "s_chan": s_chan,
        "v_chan": v_chan,
    }


def generate_first_mask(
    color_rgb: np.ndarray,
    depth: np.ndarray | None = None,
    roi: tuple[int, int, int, int] | None = None,
    fg_offset: int = 30,
    silver_s_max: int = 100,
    min_area: int = 300,
    max_area: int = 0,
    morph_kernel: int = 5,
    depth_min: float = 0.05,
    depth_max: float = 2.0,
) -> np.ndarray | None:
    """Convenience wrapper: returns a boolean mask or None if nothing found."""
    result = compute_mask(
        color_rgb, depth, roi,
        fg_offset=fg_offset,
        silver_s_max=silver_s_max,
        min_area=min_area,
        max_area=max_area,
        morph_kernel=morph_kernel,
        depth_min=depth_min,
        depth_max=depth_max,
    )
    mask = result["mask"]
    if mask.any():
        return mask.astype(bool)
    return None


def build_debug_image(
    color_rgb: np.ndarray,
    result: dict,
    params: dict,
) -> np.ndarray:
    """Build a multi-panel debug visualisation (BGR output)."""
    x1, y1, x2, y2 = result["roi"]
    roi_rgb = color_rgb[y1:y2, x1:x2]
    rh, rw = roi_rgb.shape[:2]

    panel1 = cv2.cvtColor(color_rgb.copy(), cv2.COLOR_RGB2BGR)
    cv2.rectangle(panel1, (x1, y1), (x2, y2), (0, 255, 0), 2)

    for c, area, reason in result.get("rejected_contours", []):
        shifted = c.copy()
        shifted[:, :, 0] += x1
        shifted[:, :, 1] += y1
        rej_color = (0, 0, 180) if reason == "too_large" else (128, 128, 128)
        cv2.drawContours(panel1, [shifted], -1, rej_color, 1)
        M = cv2.moments(c)
        if M["m00"] > 0:
            cx = int(M["m10"] / M["m00"]) + x1
            cy = int(M["m01"] / M["m00"]) + y1
            label = f"{area:.0f}px [{reason}]"
            cv2.putText(panel1, label, (cx - 30, cy - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.35, rej_color, 1, cv2.LINE_AA)

    for c, area in result["contours"]:
        shifted = c.copy()
        shifted[:, :, 0] += x1
        shifted[:, :, 1] += y1
        cv2.drawContours(panel1, [shifted], -1, (0, 0, 255), 2)
        M = cv2.moments(c)
        if M["m00"] > 0:
            cx = int(M["m10"] / M["m00"]) + x1
            cy = int(M["m01"] / M["m00"]) + y1
            cv2.putText(panel1, f"{area:.0f}px", (cx - 20, cy - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 255), 1, cv2.LINE_AA)

    v_color = cv2.applyColorMap(result["v_chan"], cv2.COLORMAP_JET)
    panel2_roi = cv2.resize(v_color, (rw, rh))
    panel2 = np.zeros_like(panel1)
    panel2[y1:y2, x1:x2] = panel2_roi
    cv2.putText(panel2, f"V channel (median={result['bg_v_median']}, thresh={result['fg_thresh']})",
                (10, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)

    mask_full = result["mask"]
    overlay = cv2.cvtColor(color_rgb.copy(), cv2.COLOR_RGB2BGR)
    red = np.zeros_like(overlay)
    red[:, :, 2] = 255
    mask_3ch = cv2.merge([mask_full, mask_full, mask_full])
    overlay = np.where(mask_3ch > 0,
                       cv2.addWeighted(overlay, 0.5, red, 0.5, 0),
                       overlay)
    cv2.rectangle(overlay, (x1, y1), (x2, y2), (0, 255, 0), 1)

    fg_px = int(mask_full.sum() / 255)
    n_kept = len(result["contours"])
    n_rejected = len(result.get("rejected_contours", []))
    max_area_val = params.get('max_area', 0)
    stats = [
        f"fg_offset={params.get('fg_offset', '?')}  s_max={params.get('silver_s_max', '?')}",
        f"min_area={params.get('min_area', '?')}  max_area={max_area_val if max_area_val > 0 else 'off'}  morph_k={params.get('morph_kernel', '?')}",
        f"FG: {fg_px}px  Kept: {n_kept}  Rejected: {n_rejected}",
    ]
    for i, s in enumerate(stats):
        cv2.putText(overlay, s, (10, 22 + i * 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 1, cv2.LINE_AA)

    pH = panel1.shape[0]
    pW = panel1.shape[1]
    canvas = np.zeros((pH, pW * 3, 3), dtype=np.uint8)
    canvas[:, :pW] = panel1
    canvas[:, pW:2*pW] = panel2
    canvas[:, 2*pW:] = overlay

    return canvas


# -- Interactive mode (file) ---------------------------------------------------

def _create_trackbars(win: str, args, has_frames: bool = True, n_frames: int = 0):
    cv2.createTrackbar("fg_offset", win, args.fg_offset, 150, lambda x: None)
    cv2.createTrackbar("s_max", win, args.silver_s_max, 255, lambda x: None)
    cv2.createTrackbar("min_area", win, args.min_area, 5000, lambda x: None)
    cv2.createTrackbar("max_area", win, args.max_area, 200000, lambda x: None)
    cv2.createTrackbar("morph_k", win, args.morph_kernel, 21, lambda x: None)
    if has_frames:
        cv2.createTrackbar("frame", win, 0, max(n_frames - 1, 0), lambda x: None)


def _read_trackbars(win: str, has_frames: bool = True) -> dict:
    fg_offset = cv2.getTrackbarPos("fg_offset", win)
    s_max = cv2.getTrackbarPos("s_max", win)
    min_area = cv2.getTrackbarPos("min_area", win)
    max_area = cv2.getTrackbarPos("max_area", win)
    morph_k = cv2.getTrackbarPos("morph_k", win)
    params = {
        "fg_offset": fg_offset,
        "silver_s_max": s_max,
        "min_area": max(min_area, 1),
        "max_area": max_area,
        "morph_kernel": max(morph_k, 1) | 1,
    }
    if has_frames:
        params["frame_idx"] = cv2.getTrackbarPos("frame", win)
    return params


def _print_final_params(params: dict):
    print(f"\nFinal parameters:")
    print(f"  --fg_offset {params['fg_offset']} "
          f"--silver_s_max {params['silver_s_max']} "
          f"--min_area {params['min_area']} "
          f"--max_area {params['max_area']} "
          f"--morph_kernel {params['morph_kernel']}")


def _apply_saved_params(args, saved: dict | None):
    """Override CLI defaults with previously saved mask_params."""
    if saved is None:
        return
    mapping = {
        "fg_offset": "fg_offset",
        "silver_s_max": "silver_s_max",
        "min_area": "min_area",
        "max_area": "max_area",
        "morph_kernel": "morph_kernel",
        "depth_min": "depth_min",
        "depth_max": "depth_max",
    }
    for json_key, attr in mapping.items():
        if json_key in saved and hasattr(args, attr):
            setattr(args, attr, type(getattr(args, attr))(saved[json_key]))
    print(f"[INFO] Loaded saved mask params as defaults: {saved}")


def _current_mask_params(params: dict, args) -> dict:
    """Build a mask_params dict from current trackbar values and args."""
    return {
        "fg_offset": params["fg_offset"],
        "silver_s_max": params["silver_s_max"],
        "min_area": params["min_area"],
        "max_area": params["max_area"],
        "morph_kernel": params["morph_kernel"],
        "depth_min": args.depth_min,
        "depth_max": args.depth_max,
    }


def run_interactive(scene_dir: str, args):
    """Trackbar-based interactive parameter tuning (file mode)."""
    rgb_files = sorted(glob.glob(os.path.join(scene_dir, "rgb", "*.png")))
    if not rgb_files:
        print(f"[ERROR] No images in {scene_dir}/rgb/")
        return 1

    depth_files = [f.replace("rgb", "depth") for f in rgb_files]
    roi_cfg_path = os.path.join(scene_dir, "roi_config.json")
    roi = load_roi_config(roi_cfg_path)
    if roi is None:
        print("[WARN] No roi_config.json found, using full image.")

    _apply_saved_params(args, load_mask_params(roi_cfg_path))

    win = "Mask Debug (q=quit, s=save mask, w=save params, </>= prev/next)"
    cv2.namedWindow(win, cv2.WINDOW_NORMAL)
    _create_trackbars(win, args, has_frames=True, n_frames=len(rgb_files))

    last_frame_idx = -1
    color_rgb = None
    depth = None
    params = {}

    while True:
        params = _read_trackbars(win, has_frames=True)
        frame_idx = params["frame_idx"]

        if frame_idx != last_frame_idx:
            color_rgb = imageio.imread(rgb_files[frame_idx])[..., :3]
            dp = depth_files[frame_idx]
            if os.path.exists(dp):
                depth = cv2.imread(dp, -1) / 1e3
                depth[(depth < 0.001) | (depth >= 10.0)] = 0
            else:
                depth = None
            last_frame_idx = frame_idx

        result = compute_mask(
            color_rgb, depth, roi,
            fg_offset=params["fg_offset"],
            silver_s_max=params["silver_s_max"],
            min_area=params["min_area"],
            max_area=params["max_area"],
            morph_kernel=params["morph_kernel"],
            depth_min=args.depth_min,
            depth_max=args.depth_max,
        )

        canvas = build_debug_image(color_rgb, result, params)
        cv2.imshow(win, canvas)

        key = cv2.waitKey(30) & 0xFF
        if key in (27, ord("q")):
            break
        elif key == ord("s"):
            out_dir = os.path.join(scene_dir, "masks")
            os.makedirs(out_dir, exist_ok=True)
            name = os.path.basename(rgb_files[frame_idx]).replace(".png", "")
            out_path = os.path.join(out_dir, f"{name}.png")
            cv2.imwrite(out_path, result["mask"])
            print(f"Saved mask: {out_path}")
        elif key == ord("w"):
            save_mask_params(roi_cfg_path, _current_mask_params(params, args))
        elif key == ord(",") or key == ord("<"):
            new_idx = max(0, frame_idx - 1)
            cv2.setTrackbarPos("frame", win, new_idx)
        elif key == ord(".") or key == ord(">"):
            new_idx = min(len(rgb_files) - 1, frame_idx + 1)
            cv2.setTrackbarPos("frame", win, new_idx)

    cv2.destroyAllWindows()
    _print_final_params(params)
    return 0


# -- Interactive mode (camera) -------------------------------------------------

def run_interactive_camera(args):
    """Trackbar-based interactive parameter tuning with live camera."""
    try:
        import pyrealsense2 as rs
    except ImportError:
        print("[ERROR] pyrealsense2 not installed. Run: pip install pyrealsense2")
        return 1

    ctx = rs.context()
    if len(ctx.query_devices()) == 0:
        print("[ERROR] No RealSense device found.")
        return 1

    pipeline = rs.pipeline()
    config = rs.config()
    w, h, fps = args.cam_width, args.cam_height, args.cam_fps
    config.enable_stream(rs.stream.color, w, h, rs.format.rgb8, fps)
    config.enable_stream(rs.stream.depth, w, h, rs.format.z16, fps)

    try:
        profile = pipeline.start(config)
    except Exception as e:
        print(f"[ERROR] Cannot start camera: {e}")
        return 1

    align = rs.align(rs.stream.color)
    depth_scale = profile.get_device().first_depth_sensor().get_depth_scale()
    print(f"Camera opened: {w}x{h}@{fps}fps  depth_scale={depth_scale}")

    roi_cfg_path = args.roi_config if args.roi_config else "roi_config.json"
    roi = load_roi_config(roi_cfg_path)
    if roi:
        print(f"ROI loaded: {roi}")
    else:
        print("[WARN] No valid ROI in config -- using full image. "
              "Run detect_roi.py --camera first.")

    _apply_saved_params(args, load_mask_params(roi_cfg_path))

    win = "Mask Debug LIVE (q=quit, c=freeze, s=snapshot, w=save params)"
    cv2.namedWindow(win, cv2.WINDOW_NORMAL)
    _create_trackbars(win, args, has_frames=False)

    frozen = False
    frozen_color = None
    frozen_depth = None
    params = {}

    try:
        while True:
            if not frozen:
                frames = pipeline.wait_for_frames(timeout_ms=3000)
                aligned = align.process(frames)
                color_frame = aligned.get_color_frame()
                depth_frame = aligned.get_depth_frame()
                if not color_frame or not depth_frame:
                    continue
                color_rgb = np.asanyarray(color_frame.get_data())
                depth_raw = np.asanyarray(depth_frame.get_data())
                depth = depth_raw.astype(np.float64) * depth_scale
                depth[(depth < 0.001) | (depth >= 10.0)] = 0
                frozen_color = color_rgb.copy()
                frozen_depth = depth.copy()
            else:
                color_rgb = frozen_color
                depth = frozen_depth

            params = _read_trackbars(win, has_frames=False)

            result = compute_mask(
                color_rgb, depth, roi,
                fg_offset=params["fg_offset"],
                silver_s_max=params["silver_s_max"],
                min_area=params["min_area"],
                max_area=params["max_area"],
                morph_kernel=params["morph_kernel"],
                depth_min=args.depth_min,
                depth_max=args.depth_max,
            )

            canvas = build_debug_image(color_rgb, result, params)

            status = "[FROZEN]" if frozen else "[LIVE]"
            cv2.putText(canvas, status, (canvas.shape[1] - 120, 22),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                        (0, 255, 255) if frozen else (0, 255, 0),
                        2, cv2.LINE_AA)

            cv2.imshow(win, canvas)
            key = cv2.waitKey(30) & 0xFF

            if key in (27, ord("q")):
                break
            elif key == ord("c"):
                frozen = not frozen
                if frozen:
                    print("Frozen -- adjust trackbars, press c to resume")
                else:
                    print("Resumed live feed")
            elif key == ord("w"):
                save_mask_params(roi_cfg_path,
                                 _current_mask_params(params, args))
            elif key == ord("s"):
                import time as _time
                tag = f"snapshot_{int(_time.time())}"
                os.makedirs("mask_snapshots", exist_ok=True)
                cv2.imwrite(f"mask_snapshots/{tag}_debug.png", canvas)
                cv2.imwrite(f"mask_snapshots/{tag}_mask.png", result["mask"])
                bgr = cv2.cvtColor(color_rgb, cv2.COLOR_RGB2BGR)
                cv2.imwrite(f"mask_snapshots/{tag}_rgb.png", bgr)
                print(f"Snapshot saved: mask_snapshots/{tag}_*")

    finally:
        pipeline.stop()
        cv2.destroyAllWindows()

    _print_final_params(params)
    return 0


# -- Batch mode ----------------------------------------------------------------

def run_batch(scene_dir: str, args):
    """Process all frames and optionally save masks."""
    rgb_files = sorted(glob.glob(os.path.join(scene_dir, "rgb", "*.png")))
    if not rgb_files:
        print(f"[ERROR] No images in {scene_dir}/rgb/")
        return 1

    roi_cfg_path = os.path.join(scene_dir, "roi_config.json")
    roi = load_roi_config(roi_cfg_path)
    if roi is None:
        print("[WARN] No valid ROI in roi_config.json, using full image.")

    _apply_saved_params(args, load_mask_params(roi_cfg_path))

    out_dir = os.path.join(scene_dir, "masks")
    if args.save:
        os.makedirs(out_dir, exist_ok=True)

    debug_dir = os.path.join(scene_dir, "mask_debug")
    if args.save_debug:
        os.makedirs(debug_dir, exist_ok=True)

    print(f"Processing {len(rgb_files)} frames  (ROI={roi})")
    print(f"  fg_offset={args.fg_offset}  silver_s_max={args.silver_s_max}  "
          f"min_area={args.min_area}  morph_kernel={args.morph_kernel}")

    for idx, rgb_path in enumerate(rgb_files):
        name = os.path.basename(rgb_path).replace(".png", "")
        color_rgb = imageio.imread(rgb_path)[..., :3]

        depth_path = rgb_path.replace("rgb", "depth")
        depth = None
        if os.path.exists(depth_path):
            depth = cv2.imread(depth_path, -1) / 1e3
            depth[(depth < 0.001) | (depth >= 10.0)] = 0

        result = compute_mask(
            color_rgb, depth, roi,
            fg_offset=args.fg_offset,
            silver_s_max=args.silver_s_max,
            min_area=args.min_area,
            max_area=args.max_area,
            morph_kernel=args.morph_kernel,
            depth_min=args.depth_min,
            depth_max=args.depth_max,
        )

        mask = result["mask"]
        fg_px = int(mask.sum() / 255)
        n_kept = len(result["contours"])
        n_rej = len(result.get("rejected_contours", []))
        areas = [f"{a:.0f}" for _, a in result["contours"]]

        print(f"  [{name}] bg_V_med={result['bg_v_median']}  "
              f"thresh={result['fg_thresh']}  "
              f"fg_px={fg_px}  kept={n_kept}  rejected={n_rej}  "
              f"areas=[{', '.join(areas)}]")

        if args.save:
            cv2.imwrite(os.path.join(out_dir, f"{name}.png"), mask)

        if args.save_debug:
            params = {
                "fg_offset": args.fg_offset,
                "silver_s_max": args.silver_s_max,
                "min_area": args.min_area,
                "max_area": args.max_area,
                "morph_kernel": args.morph_kernel,
            }
            canvas = build_debug_image(color_rgb, result, params)
            cv2.imwrite(os.path.join(debug_dir, f"{name}_debug.png"), canvas)

    if args.save:
        print(f"\nMasks saved to: {out_dir}")
    if args.save_debug:
        print(f"Debug images saved to: {debug_dir}")
    return 0


# -- CLI -----------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Generate and debug masks for conveyor-belt workpiece detection"
    )

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--scene_dir", type=str, default=None,
                       help="Scene directory with rgb/, depth/ (file mode)")
    group.add_argument("--camera", action="store_true", default=False,
                       help="Use live RealSense camera feed")

    parser.add_argument("--interactive", action="store_true",
                        help="Launch interactive trackbar GUI for parameter tuning")
    parser.add_argument("--save", action="store_true",
                        help="Save masks to {scene_dir}/masks/ (file mode only)")
    parser.add_argument("--save_debug", action="store_true",
                        help="Save debug images to {scene_dir}/mask_debug/ (file mode only)")

    parser.add_argument("--fg_offset", type=int, default=30,
                        help="Foreground V offset above background median (default: 30)")
    parser.add_argument("--silver_s_max", type=int, default=100,
                        help="Max saturation for metallic surfaces (default: 100)")
    parser.add_argument("--min_area", type=int, default=300,
                        help="Minimum contour area in pixels (default: 300)")
    parser.add_argument("--max_area", type=int, default=0,
                        help="Maximum contour area in pixels; 0=no limit (default: 0). "
                             "Set to ~3x expected object area to filter out lights.")
    parser.add_argument("--morph_kernel", type=int, default=5,
                        help="Morphology kernel size (default: 5)")
    parser.add_argument("--depth_min", type=float, default=0.05,
                        help="Minimum valid depth in meters (default: 0.05)")
    parser.add_argument("--depth_max", type=float, default=2.0,
                        help="Maximum valid depth in meters (default: 2.0)")

    parser.add_argument("--roi_config", type=str, default=None,
                        help="Path to roi_config.json (camera mode)")
    parser.add_argument("--cam_width", type=int, default=1280)
    parser.add_argument("--cam_height", type=int, default=720)
    parser.add_argument("--cam_fps", type=int, default=30)

    args = parser.parse_args()

    if args.camera:
        if not args.interactive:
            print("[INFO] Camera mode defaults to --interactive")
            args.interactive = True
        return run_interactive_camera(args)
    else:
        if args.interactive:
            return run_interactive(args.scene_dir, args)
        else:
            return run_batch(args.scene_dir, args)


if __name__ == "__main__":
    raise SystemExit(main())
