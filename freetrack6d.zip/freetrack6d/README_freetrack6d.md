# FreeTrack6D 运行文件


## 已包含

- 入口及递归依赖的相机、ROI/掩码、卡尔曼跟踪、机械臂控制、坐标变换、渲染和 FoundationPose 模块。
- `learning/` 中的网络、推理和数据处理源码。
- 精修权重：`weights/2023-10-28-18-33-37/{config.yml,model_best.pth}`。
- 评分权重：`weights/2024-01-11-20-02-45/{config.yml,model_best.pth}`。
- `mycpp` 和 `bundlesdf/mycuda` 的源码及现有原生扩展。
- `demo_data/888/mesh/` 的 9 个模型文件，示例使用 `obj_12output.obj`。
- `roi_config.json`、`realsense_pose_xp1.txt` 及辅助模块使用的标定/路点文本。
- 原始依赖清单、构建脚本、Docker 文件、项目说明和许可证。

## 运行

先进入本目录并激活原来可运行 FoundationPose 的环境。纯视觉模式：

```bash
python main_online_kalman_suction_fixed_z.py --mesh_file demo_data/888/mesh/obj_12output.obj --roi_config roi_config.json --no_arm
```

包含机械臂的原始运行方式：

```bash
python main_online_kalman_suction_fixed_z.py --mesh_file demo_data/888/mesh/obj_12output.obj --roi_config roi_config.json --calib realsense_pose_xp1.txt
```

以上命令使用源码中的参数默认值。相机仍须连接；机械臂模式会连接源码配置的机器人。现有路点保存在入口的 `RIGHT_ARM_WAYPOINTS` 中，按 `g` 启动抓取周期。若原来使用了其他命令行参数，请继续传入相同参数。

