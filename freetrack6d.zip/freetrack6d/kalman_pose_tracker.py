"""
6D Pose Kalman Filter with KF-based prediction for both translation and rotation.

"""

from __future__ import annotations

import numpy as np
from scipy.spatial.transform import Rotation


def estimate_constant_velocity(
    samples: list[tuple[float, np.ndarray]],
    max_speed: float,
    outlier_threshold: float,
) -> tuple[np.ndarray, dict[str, float | int]]:
    """Robustly fit constant 3D velocity to timestamped positions.

    Pairwise median slopes provide an outlier-resistant initial estimate.
    Residual gating is then followed by a least-squares fit over the retained
    samples.  This is intended for lightweight conveyor motion estimation
    while the GPU is occupied by pose registration.
    """
    if len(samples) < 2:
        return np.zeros(3), {
            "samples": len(samples),
            "inliers": len(samples),
            "rmse": 0.0,
        }

    samples = sorted(samples, key=lambda item: item[0])
    times = np.asarray([item[0] for item in samples], dtype=np.float64)
    positions = np.asarray([item[1] for item in samples], dtype=np.float64)
    finite = np.isfinite(times) & np.isfinite(positions).all(axis=1)
    times = times[finite]
    positions = positions[finite]
    if len(times) < 2:
        return np.zeros(3), {
            "samples": len(times),
            "inliers": len(times),
            "rmse": 0.0,
        }

    keep = np.concatenate([[True], np.diff(times) > 1e-6])
    times = times[keep]
    positions = positions[keep]
    if len(times) < 2:
        return np.zeros(3), {
            "samples": len(times),
            "inliers": len(times),
            "rmse": 0.0,
        }

    relative_time = times - times[0]
    row, col = np.triu_indices(len(times), k=1)
    pair_dt = relative_time[col] - relative_time[row]
    valid_pairs = pair_dt > 1e-4
    if not np.any(valid_pairs):
        return np.zeros(3), {
            "samples": len(times),
            "inliers": len(times),
            "rmse": 0.0,
        }
    pair_slopes = (
        positions[col[valid_pairs]] - positions[row[valid_pairs]]
    ) / pair_dt[valid_pairs, None]
    velocity_initial = np.median(pair_slopes, axis=0)

    intercept = np.median(
        positions - relative_time[:, None] * velocity_initial[None],
        axis=0,
    )
    residuals = np.linalg.norm(
        positions
        - (
            intercept[None]
            + relative_time[:, None] * velocity_initial[None]
        ),
        axis=1,
    )
    residual_median = float(np.median(residuals))
    residual_mad = float(np.median(np.abs(residuals - residual_median)))
    robust_sigma = 1.4826 * residual_mad
    threshold = max(
        float(outlier_threshold),
        residual_median + 3.0 * robust_sigma,
    )
    inliers = residuals <= threshold

    if int(inliers.sum()) >= 2:
        design = np.column_stack(
            [relative_time[inliers], np.ones(int(inliers.sum()))]
        )
        coefficients, _, _, _ = np.linalg.lstsq(
            design,
            positions[inliers],
            rcond=None,
        )
        velocity = coefficients[0]
        fitted = design @ coefficients
        rmse = float(
            np.sqrt(
                np.mean(
                    np.sum((positions[inliers] - fitted) ** 2, axis=1)
                )
            )
        )
    else:
        velocity = velocity_initial
        rmse = residual_median

    speed = float(np.linalg.norm(velocity))
    if max_speed > 0.0 and speed > max_speed:
        velocity = velocity * (max_speed / speed)

    return velocity, {
        "samples": len(times),
        "inliers": int(inliers.sum()),
        "rmse": rmse,
    }


class PoseKalmanFilter:
    """6D pose tracker combining linear KF (translation) and angular-velocity
    KF (rotation).

    Args:
        q_pos:  process noise std-dev on position (metres).
        q_vel:  process noise std-dev on velocity (m/s).
            Lower → smoother velocity estimate → less prediction jitter,
            but slower response to real speed changes.
        r_pos:  measurement noise std-dev on position (metres).
        q_omega:  process noise std-dev for angular velocity KF (rad/s).
            Controls how quickly the angular velocity estimate can change.
        r_omega:  measurement noise std-dev for angular velocity KF (rad/s).
            Reflects noise in frame-to-frame rotation measurements.
        max_speed: maximum translational speed (m/s).
        vel_deadzone: speeds below this (m/s) are treated as zero
            for prediction.
        warmup_frames: updates before velocity predictions activate.
    """

    def __init__(
        self,
        q_pos: float = 0.002,
        q_vel: float = 0.005,
        r_pos: float = 0.005,
        q_omega: float = 0.02,
        r_omega: float = 0.5,
        max_speed: float = 0.05,
        vel_deadzone: float = 0.003,
        warmup_frames: int = 10,
    ):
        self._q_pos = q_pos
        self._q_vel = q_vel
        self._r_pos = r_pos
        self._q_omega = q_omega
        self._r_omega = r_omega
        self._max_speed = max_speed
        self._vel_deadzone = vel_deadzone
        self._warmup_frames = warmup_frames

        # ---- Translation KF state: [x, y, z, vx, vy, vz] --------------------
        self._x = np.zeros(6)
        self._P = np.eye(6)
        self._H = np.zeros((3, 6))
        self._H[:3, :3] = np.eye(3)
        self._R_meas = np.eye(3) * r_pos ** 2

        # ---- Rotation state ---------------------------------------------------
        self._R_rot = np.eye(3)

        # ---- Angular velocity KF state: [wx, wy, wz] -------------------------
        self._omega_x = np.zeros(3)
        self._omega_P = np.eye(3) * 0.1
        self._omega_Q_base = q_omega ** 2
        self._omega_R = np.eye(3) * r_omega ** 2

        # ---- Bookkeeping ------------------------------------------------------
        self._initialized = False
        self._frozen = False
        self._last_time: float = 0.0
        self._last_valid_pose = np.eye(4)
        self._frozen_velocity = np.zeros(3)
        self._frozen_omega = np.zeros(3)
        self._update_count = 0

    # -- Properties ------------------------------------------------------------

    @property
    def initialized(self) -> bool:
        return self._initialized

    @property
    def frozen(self) -> bool:
        return self._frozen

    @property
    def warmed_up(self) -> bool:
        """True when enough frames have been processed for reliable velocity."""
        return self._update_count >= self._warmup_frames

    @property
    def velocity(self) -> np.ndarray:
        """Translational velocity [vx, vy, vz] m/s from translation KF."""
        if self._frozen:
            return self._frozen_velocity.copy()
        return self._x[3:].copy()

    @property
    def angular_velocity(self) -> np.ndarray:
        """Angular velocity [wx, wy, wz] rad/s from angular-velocity KF."""
        if self._frozen:
            return self._frozen_omega.copy()
        return self._omega_x.copy()

    @property
    def prediction_velocity(self) -> np.ndarray:
        """Translational velocity used for predictions (dead-zone applied)."""
        vel = self.velocity
        if not self.warmed_up or np.linalg.norm(vel) < self._vel_deadzone:
            return np.zeros(3)
        return vel

    @property
    def prediction_omega(self) -> np.ndarray:
        """Angular velocity used for predictions (dead-zone applied)."""
        omega = self.angular_velocity
        if not self.warmed_up or np.linalg.norm(omega) < np.radians(0.5):
            return np.zeros(3)
        return omega

    @property
    def speed(self) -> float:
        """Translational speed (m/s) for display (dead-zone applied)."""
        return float(np.linalg.norm(self.prediction_velocity))

    @property
    def raw_speed(self) -> float:
        """Raw KF translational speed (m/s), no dead-zone."""
        return float(np.linalg.norm(self.velocity))

    @property
    def update_count(self) -> int:
        return self._update_count

    @property
    def last_timestamp(self) -> float:
        """Timestamp of the most recent accepted measurement."""
        return self._last_time

    # -- Core API --------------------------------------------------------------

    def initialize(
        self,
        pose_4x4: np.ndarray,
        timestamp: float,
        velocity: np.ndarray | None = None,
        angular_velocity: np.ndarray | None = None,
    ):
        """Set the filter to a known initial pose.

        Velocities default to zero.  Supplying a measured conveyor velocity
        seeds prediction immediately, which is useful when pose registration
        finishes several seconds after its source frame was captured.  The
        filter is unfrozen automatically.
        """
        self._x[:3] = pose_4x4[:3, 3]
        if velocity is None:
            self._x[3:] = 0.0
        else:
            self._x[3:] = np.asarray(velocity, dtype=np.float64).reshape(3)
            self._clamp_velocity()

        self._P = np.eye(6)
        self._P[:3, :3] *= self._r_pos ** 2
        self._P[3:, 3:] *= 0.01

        self._R_rot = pose_4x4[:3, :3].copy()
        if angular_velocity is None:
            self._omega_x = np.zeros(3)
        else:
            self._omega_x = np.asarray(
                angular_velocity, dtype=np.float64,
            ).reshape(3)
        self._omega_P = np.eye(3) * 0.1

        self._last_time = timestamp
        self._initialized = True
        self._frozen = False
        self._last_valid_pose = pose_4x4.copy()
        self._frozen_velocity = np.zeros(3)
        self._frozen_omega = np.zeros(3)
        has_motion_seed = velocity is not None or angular_velocity is not None
        self._update_count = self._warmup_frames if has_motion_seed else 0

    def update(self, pose_4x4: np.ndarray, timestamp: float):
        """Incorporate a new 6D pose measurement.

        Does nothing if the filter is frozen or uninitialised.
        """
        if not self._initialized or self._frozen:
            return

        dt = timestamp - self._last_time
        if dt <= 1e-6:
            return

        # ---- Translation KF: predict step ------------------------------------
        F = np.eye(6)
        F[0, 3] = dt
        F[1, 4] = dt
        F[2, 5] = dt

        q_p = (self._q_pos * dt) ** 2
        q_v = (self._q_vel * dt) ** 2
        q_pv = self._q_pos * self._q_vel * dt ** 2
        Q = np.zeros((6, 6))
        Q[:3, :3] = np.eye(3) * q_p
        Q[3:, 3:] = np.eye(3) * q_v
        Q[:3, 3:] = np.eye(3) * q_pv
        Q[3:, :3] = np.eye(3) * q_pv

        x_pred = F @ self._x
        P_pred = F @ self._P @ F.T + Q

        # ---- Translation KF: measurement update ------------------------------
        z = pose_4x4[:3, 3]
        y = z - self._H @ x_pred
        S = self._H @ P_pred @ self._H.T + self._R_meas
        K = P_pred @ self._H.T @ np.linalg.inv(S)
        self._x = x_pred + K @ y
        self._P = (np.eye(6) - K @ self._H) @ P_pred

        # ---- Velocity clamping -----------------------------------------------
        self._clamp_velocity()

        # ---- Angular velocity KF: measurement --------------------------------
        R_new = pose_4x4[:3, :3]
        dR = self._R_rot.T @ R_new
        rotvec = Rotation.from_matrix(dR).as_rotvec()
        z_omega = rotvec / dt

        # ---- Angular velocity KF: predict step (constant-omega model) --------
        omega_pred = self._omega_x.copy()
        P_omega_pred = self._omega_P + np.eye(3) * (self._omega_Q_base * dt)

        # ---- Angular velocity KF: update step --------------------------------
        y_omega = z_omega - omega_pred
        S_omega = P_omega_pred + self._omega_R
        K_omega = P_omega_pred @ np.linalg.inv(S_omega)
        self._omega_x = omega_pred + K_omega @ y_omega
        self._omega_P = (np.eye(3) - K_omega) @ P_omega_pred

        # ---- Bookkeeping -----------------------------------------------------
        self._R_rot = R_new.copy()
        self._last_time = timestamp
        self._update_count += 1
        self._last_valid_pose = self._build_pose(self._x[:3], self._R_rot)

    def predict(self, dt_future: float) -> np.ndarray:
        """Predict the full 6D (4x4) pose at *dt_future* seconds from now.

        Translation is extrapolated using the KF velocity estimate.
        Rotation is extrapolated using the angular-velocity KF estimate
        via the Rodrigues (exponential map) formula.

        During warmup or when frozen, returns the current/last-valid pose.
        """
        if not self._initialized:
            return np.eye(4)

        if self._frozen:
            return self._last_valid_pose.copy()

        # Translation prediction via KF velocity
        vel = self._x[3:].copy()
        if not self.warmed_up or np.linalg.norm(vel) < self._vel_deadzone:
            vel = np.zeros(3)
        p_pred = self._x[:3] + vel * dt_future

        # Rotation prediction via angular-velocity KF
        omega = self._omega_x.copy()
        if not self.warmed_up or np.linalg.norm(omega) < np.radians(0.5):
            omega = np.zeros(3)
        R_pred = self._predict_rotation(dt_future, self._R_rot, omega)

        return self._build_pose(p_pred, R_pred)

    def get_current_pose(self) -> np.ndarray:
        """Return the best current 4x4 pose estimate.

        When frozen, returns the cached last-valid pose (unchanged).
        """
        if self._frozen:
            return self._last_valid_pose.copy()
        if not self._initialized:
            return np.eye(4)
        return self._build_pose(self._x[:3], self._R_rot)

    def generate_pose_hypotheses(
        self,
        dt: float,
        translation_step: float = 0.025,
        rotation_step_deg: float = 10.0,
        include_current: bool = True,
        max_hypotheses: int = 5,
    ) -> list[np.ndarray]:
        """Generate Kalman-guided priors for FoundationPose refinement.

        The first hypothesis is the constant-velocity prediction at the
        requested frame time.  Remaining hypotheses cover the last filtered
        pose, translations along the estimated motion direction and camera
        axes, and rotations around the estimated angular-motion direction and
        camera axes.  The method never mutates the Kalman state.

        Candidates are prediction-first and then truncated to the requested
        computation budget; the online bridge uses five hypotheses.
        """
        if not self._initialized:
            return [np.eye(4)]

        dt = max(float(dt), 0.0)
        base = self.predict(dt)
        candidates: list[np.ndarray] = [base]

        if include_current:
            candidates.append(self.get_current_pose())

        translation_axes: list[np.ndarray] = []
        velocity = self.prediction_velocity
        speed = float(np.linalg.norm(velocity))
        if speed > 1e-9:
            translation_axes.append(velocity / speed)
        translation_axes.extend(np.eye(3))

        step = max(float(translation_step), 0.0)
        if step > 0.0:
            for axis in translation_axes:
                for sign in (-1.0, 1.0):
                    pose = base.copy()
                    pose[:3, 3] += sign * step * axis
                    candidates.append(pose)

        rotation_axes: list[np.ndarray] = []
        omega = self.prediction_omega
        omega_norm = float(np.linalg.norm(omega))
        if omega_norm > 1e-9:
            # The angular KF stores a body-frame rotation vector because
            # prediction post-multiplies R.  Convert it to a camera-frame axis
            # before applying camera-frame perturbations below.
            rotation_axes.append(base[:3, :3] @ (omega / omega_norm))
        rotation_axes.extend(np.eye(3))

        angle = np.deg2rad(max(float(rotation_step_deg), 0.0))
        if angle > 0.0:
            for axis in rotation_axes:
                axis_norm = float(np.linalg.norm(axis))
                if axis_norm < 1e-9:
                    continue
                axis = axis / axis_norm
                for sign in (-1.0, 1.0):
                    pose = base.copy()
                    delta = Rotation.from_rotvec(sign * angle * axis).as_matrix()
                    pose[:3, :3] = delta @ base[:3, :3]
                    candidates.append(pose)

        unique = self._dedupe_poses(candidates)
        if max_hypotheses > 0:
            unique = unique[:max_hypotheses]
        return unique

    # -- Freeze / unfreeze -----------------------------------------------------

    def freeze(self):
        """Stop accepting updates; lock current state for repeated output."""
        if self._initialized and not self._frozen:
            self._frozen = True
            self._frozen_velocity = self._x[3:].copy()
            self._frozen_omega = self._omega_x.copy()
            self._last_valid_pose = self._build_pose(self._x[:3], self._R_rot)

    def unfreeze(self):
        """Allow updates again (typically after re-mask / re-registration)."""
        self._frozen = False

    # -- Internal helpers -------------------------------------------------------

    def _clamp_velocity(self):
        if self._max_speed <= 0:
            return
        spd = np.linalg.norm(self._x[3:])
        if spd > self._max_speed:
            self._x[3:] *= self._max_speed / spd

    @staticmethod
    def _dedupe_poses(poses: list[np.ndarray]) -> list[np.ndarray]:
        unique: list[np.ndarray] = []
        keys: set[tuple[float, ...]] = set()
        for pose in poses:
            pose = np.asarray(pose, dtype=np.float64).reshape(4, 4)
            key = tuple(np.round(pose[:3, :].reshape(-1), 6))
            if key in keys:
                continue
            keys.add(key)
            unique.append(pose.copy())
        return unique

    @staticmethod
    def _predict_rotation(
        dt: float, R_base: np.ndarray, omega: np.ndarray,
    ) -> np.ndarray:
        omega_norm = np.linalg.norm(omega)
        if omega_norm < 1e-8 or abs(dt) < 1e-8:
            return R_base.copy()
        rotvec = omega * dt
        dR = Rotation.from_rotvec(rotvec).as_matrix()
        return R_base @ dR

    @staticmethod
    def _build_pose(position: np.ndarray, rotation: np.ndarray) -> np.ndarray:
        pose = np.eye(4)
        pose[:3, :3] = rotation
        pose[:3, 3] = position
        return pose
