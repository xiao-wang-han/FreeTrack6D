

from __future__ import annotations

import argparse
from collections import deque
import enum
import logging
import os
import queue
import sys
import threading
import time
from typing import Callable

import cv2
import numpy as np

_code_dir = os.path.dirname(os.path.realpath(__file__))
if _code_dir not in sys.path:
    sys.path.insert(0, _code_dir)

from estimater import *  # noqa: E402,F403
from datareader import *  # noqa: E402,F403

try:
    import mycpp  # noqa: F401
except ImportError:
    pass

from camera_reader import (  # noqa: E402
    RealSenseCameraReader,
    check_realsense_connection,
)
from detect_roi import load_mask_params, load_roi_config  # noqa: E402
from generate_mask import compute_mask  # noqa: E402
from kalman_pose_tracker import (  # noqa: E402
    PoseKalmanFilter,
    estimate_constant_velocity,
)
from arm_controller import _try_connect_rtde  # noqa: E402
from coordinate_transform import (  # noqa: E402
    is_point_in_expanded_roi,
    load_calibration,
    project_base_pose_to_image,
)


class TrackingState(enum.Enum):
    WAITING_MASK = "waiting-mask"
    REGISTERING = "registering"
    BRIDGING = "kalman-mask-bridge"
    TRACKING = "tracking"


class GraspState(enum.Enum):
    IDLE = "idle"
    FOLLOW_ROI = "follow-to-roi"
    FINISHING = "predicted-pick-place"


CONTROL_REVISION = "rtde-servol-vision-reset-preserves-place-v4"

# Absolute robot-base Z of the final commanded pose, in metres (not an offset).
FINAL_GRASP_Z_M = -0.045
PLACE_LAYER_STEP_M = 0.032


# TODO: replace each None with a UR pose [x, y, z, rx, ry, rz].
# Translation is in metres and rotation is a Rodrigues vector in radians.
# The poses must be taught with the same TCP configured by --tool_height.
RIGHT_ARM_WAYPOINTS: dict[str, np.ndarray | None] = {
    "start": [-0.31585, 0.34416, 0.09523, 2.406, -2.128, 0.008],
    "middle1": [-0.07507, 0.40470, 0.13600, 2.406, -2.128, 0.008],
    "middle2": [0.49531, 0.11076, 0.09401, 2.406, -2.128, 0.008],
    "place": [0.49531, 0.11076, -0.04075, 2.406, -2.128, 0.008],
}


def _parse_right_arm_waypoints(path: str) -> dict[str, np.ndarray]:
    """Parse four right-arm poses from a millimetre-based waypoint file."""
    label_tokens = (
        ("middle1", ("中间姿态1", "中间位置1", "中间1", "middle1", "mid1")),
        ("middle2", ("中间姿态2", "中间位置2", "中间2", "middle2", "mid2")),
        ("start", ("初始姿态", "初始位置", "起点", "initial", "start")),
        ("place", ("放置姿态", "放置位置", "放置", "place")),
    )
    result: dict[str, np.ndarray] = {}
    with open(path, "r", encoding="utf-8") as stream:
        for line_number, raw_line in enumerate(stream, 1):
            line = raw_line.strip().replace("，", ",")
            if not line:
                continue
            parts = [part.strip() for part in line.split(",") if part.strip()]
            if len(parts) < 7:
                continue
            try:
                values = [float(parts[index]) for index in range(6)]
            except ValueError:
                continue
            label = "".join(parts[6:]).lower().replace("_", "")
            key = next(
                (
                    name
                    for name, tokens in label_tokens
                    if any(token in label for token in tokens)
                ),
                None,
            )
            if key is None:
                logging.warning(
                    "Waypoint line %d has an unknown label: %s",
                    line_number,
                    label,
                )
                continue
            result[key] = np.array(
                [
                    values[0] / 1000.0,
                    values[1] / 1000.0,
                    values[2] / 1000.0,
                    values[3],
                    values[4],
                    values[5],
                ],
                dtype=np.float64,
            )

    missing = [name for name in RIGHT_ARM_WAYPOINTS if name not in result]
    if missing:
        raise ValueError(
            f"Missing right-arm waypoints in {path}: {', '.join(missing)}"
        )
    return result


def _load_right_arm_waypoints(path: str | None) -> dict[str, np.ndarray]:
    if path:
        return _parse_right_arm_waypoints(path)
    missing = [
        name
        for name, pose in RIGHT_ARM_WAYPOINTS.items()
        if pose is None or np.asarray(pose).size != 6
    ]
    if missing:
        raise ValueError(
            "Right-arm waypoint placeholders are not filled: "
            + ", ".join(missing)
            + ". Fill RIGHT_ARM_WAYPOINTS or pass --waypoints_file."
        )
    return {
        name: np.asarray(pose, dtype=np.float64).reshape(6).copy()
        for name, pose in RIGHT_ARM_WAYPOINTS.items()
    }


def _tool_z_down_rotation(yaw_deg: float) -> np.ndarray:
    """Return a proper rotation whose TCP local +Z points along base -Z."""
    yaw = np.deg2rad(float(yaw_deg))
    x_axis = np.array([np.cos(yaw), np.sin(yaw), 0.0], dtype=np.float64)
    z_axis = np.array([0.0, 0.0, -1.0], dtype=np.float64)
    y_axis = np.cross(z_axis, x_axis)
    y_axis /= max(float(np.linalg.norm(y_axis)), 1e-12)
    x_axis = np.cross(y_axis, z_axis)
    x_axis /= max(float(np.linalg.norm(x_axis)), 1e-12)
    return np.column_stack((x_axis, y_axis, z_axis))


def _pose6_with_fixed_down_orientation(position: np.ndarray, yaw_deg: float) -> np.ndarray:
    rotation = _tool_z_down_rotation(yaw_deg)
    # Explicit invariant: the commanded tool +Z axis must face base -Z.
    if float(rotation[:, 2] @ np.array([0.0, 0.0, -1.0])) < 1.0 - 1e-9:
        raise RuntimeError("Failed to construct a tool-Z-down rotation")
    rvec, _ = cv2.Rodrigues(rotation)
    return np.concatenate((np.asarray(position, dtype=np.float64), rvec.ravel()))


def _select_suction_tool_height(
    center_pose_in_base: np.ndarray,
    z_down_height_m: float,
    z_up_height_m: float,
) -> float:
    """Classify the displayed object's local +Z against robot-base +Z.

    Use the OBB-centred pose, matching _draw_pose's coordinate axes, before
    replacing the commanded tool orientation with the fixed downward pose.
    An exactly horizontal Z axis uses the upward setting deterministically.
    """
    return float(z_down_height_m if center_pose_in_base[2, 2] < 0.0 else z_up_height_m)


def compute_suction_target(
    T_cam_to_base: np.ndarray,
    pose_vertex_in_cam: np.ndarray,
    model_vertices: np.ndarray,
    to_origin_inv: np.ndarray,
    clearance_m: float,
    tool_height_m: float,
    tcp_mode: str,
    yaw_deg: float,
    tool_height_z_down_m: float = 0.17,
    tool_height_z_up_m: float = 0.15,
    use_directional_height: bool = False,
) -> np.ndarray:
    """Build a moving grasp target with tool +Z fixed vertically downward.

    The contact height is the highest transformed mesh vertex in robot-base Z,
    rather than the object origin.  This remains valid when FoundationPose
    reports the object's local Z axis pointing either upward or downward.

    During visual following, use the fixed tool_height_m.  Enable
    use_directional_height only once when freezing the final contact target:
    the final predicted object's displayed +Z in robot-base coordinates
    selects down=0.17m or up=0.15m.  The tool itself always points downward.
    In ``controller`` mode the configured TCP stays at tool_height_m and only
    (effective_height - tool_height_m) is added to base Z.  This gives the
    same flange target as changing setTcp without shifting TCP feedback or
    taught waypoints.  In ``software`` mode add the full effective height.
    """
    pose_vertex_in_cam = np.asarray(pose_vertex_in_cam, dtype=np.float64).reshape(4, 4)
    pose_vertex_in_base = T_cam_to_base @ pose_vertex_in_cam
    center_in_base = T_cam_to_base @ (pose_vertex_in_cam @ to_origin_inv)

    vertices = np.asarray(model_vertices, dtype=np.float64).reshape(-1, 3)
    vertices_base = (
        pose_vertex_in_base[:3, :3] @ vertices.T
    ).T + pose_vertex_in_base[:3, 3]
    object_top_z = float(np.max(vertices_base[:, 2]))

    position = center_in_base[:3, 3].copy()
    position[2] = object_top_z + float(clearance_m)
    effective_height = float(tool_height_m)
    if use_directional_height:
        effective_height = _select_suction_tool_height(
            center_in_base, tool_height_z_down_m, tool_height_z_up_m,
        )
    if tcp_mode == "software":
        position[2] += effective_height
    else:
        position[2] += effective_height - float(tool_height_m)
    return _pose6_with_fixed_down_orientation(position, yaw_deg)


def _rotation_step(current_rvec: np.ndarray, target_rvec: np.ndarray, max_angle: float) -> np.ndarray:
    R_current, _ = cv2.Rodrigues(np.asarray(current_rvec, dtype=np.float64))
    R_target, _ = cv2.Rodrigues(np.asarray(target_rvec, dtype=np.float64))
    error_rvec, _ = cv2.Rodrigues(R_target @ R_current.T)
    error = error_rvec.ravel()
    angle = float(np.linalg.norm(error))
    if angle > max_angle > 0.0:
        error *= max_angle / angle
    R_step, _ = cv2.Rodrigues(error)
    result, _ = cv2.Rodrigues(R_step @ R_current)
    return result.ravel()


def _limit_vector_norm(vector: np.ndarray, limit: float) -> np.ndarray:
    norm = float(np.linalg.norm(vector))
    return vector * min(1.0, limit / max(norm, 1e-12))


def _smooth_servo_velocity(error, velocity, period, alpha, max_speed, max_acceleration):
    """Low-pass position tracking with bounded velocity and acceleration.

    Start braking before reaching the target.  Do not snap to a new target or
    reset velocity when a noisy measurement changes direction.
    """
    distance = float(np.linalg.norm(error))
    braking_speed = np.sqrt(2.0 * max_acceleration * distance)
    desired = _limit_vector_norm(alpha * error / period, min(max_speed, braking_speed))
    change = _limit_vector_norm(desired - velocity, max_acceleration * period)
    return _limit_vector_norm(velocity + change, max_speed)


class SuctionArmController:
    """UR Cartesian visual servo plus IO-controlled vacuum pick/place."""

    def __init__(self, rtde, control, io, waypoints: dict[str, np.ndarray], args):
        if rtde is None or control is None or io is None:
            raise RuntimeError(
                "Visual servo requires RTDE feedback; install ur-rtde and verify the robot IP."
            )
        self.rtde = rtde
        self.control = control
        self.io = io
        self.waypoints = waypoints
        self.args = args
        # RTDEControlInterface is not thread safe.  Serialize all its calls;
        # IO has its own interface and never interrupts the control script.
        self._control_lock = threading.Lock()
        self._io_lock = threading.Lock()
        self._target_lock = threading.Lock()
        self._servo_target: np.ndarray | None = None
        self._servo_pose: np.ndarray | None = None
        self._servo_stop = threading.Event()
        self._servo_thread: threading.Thread | None = None
        self._last_target_update_time = 0.0
        self._servo_velocity = np.zeros(3, dtype=np.float64)
        self._servo_angular_velocity = np.zeros(3, dtype=np.float64)
        self._motion_kind: str | None = None
        self.shutdown_event = threading.Event()
        self.servo_error: BaseException | None = None
        self.vacuum_enabled = False
        # Count releases at place, not key presses or successful return moves.
        # Kept across home/re-registration and reset with a new controller.
        self.completed_place_count = 0

    def configure_tool(self):
        if self.args.tcp_mode == "controller":
            height = float(self.args.tool_height)
            with self._control_lock:
                if not self.control.setTcp([0.0, 0.0, height, 0.0, 0.0, 0.0]):
                    raise RuntimeError("RTDE rejected suction TCP configuration")
            logging.info("Configured suction TCP: local +Z offset %.4fm", height)
            time.sleep(0.1)
        else:
            logging.info(
                "Software tool-height compensation enabled: %.4fm; UR TCP is unchanged",
                self.args.tool_height,
            )

    def get_tcp_pose(self) -> np.ndarray | None:
        try:
            pose = np.asarray(self.rtde.getActualTCPPose(), dtype=np.float64).reshape(6)
            return pose if np.all(np.isfinite(pose)) else None
        except Exception as exc:
            logging.warning("RTDE TCP read failed: %s", exc)
            return None

    def set_vacuum(self, enabled: bool):
        electrical = bool(enabled) != bool(self.args.vacuum_active_low)
        value = "True" if electrical else "False"
        with self._io_lock:
            if not self.io.setStandardDigitalOut(int(self.args.vacuum_io), electrical):
                raise RuntimeError("RTDE rejected vacuum output change")
            self.vacuum_enabled = bool(enabled)
        logging.info(
            "Vacuum %s: standard digital output %d=%s",
            "ON" if enabled else "OFF",
            self.args.vacuum_io,
            value,
        )

    def _arrived(self, target: np.ndarray) -> bool:
        actual = self.get_tcp_pose()
        if actual is None:
            return False
        pos_error = float(np.linalg.norm(actual[:3] - target[:3]))
        R_actual, _ = cv2.Rodrigues(actual[3:])
        R_target, _ = cv2.Rodrigues(target[3:])
        relative = R_target @ R_actual.T
        rotvec, _ = cv2.Rodrigues(relative)
        return (
            pos_error <= self.args.arrival_pos_tolerance
            and float(np.linalg.norm(rotvec)) <= self.args.arrival_rot_tolerance
        )

    def move_and_wait(self, target: np.ndarray, label: str) -> bool:
        self.stop_servo(send_stop=False)
        target = np.asarray(target, dtype=np.float64).reshape(6)
        if not np.all(np.isfinite(target)):
            raise ValueError("Non-finite moveL target")
        logging.info("Arm moving to %s: target=%s", label,
                     np.array2string(target, precision=5))
        with self._control_lock:
            if self.shutdown_event.is_set():
                return False
            previous_progress = self.control.getAsyncOperationProgress()
            self._motion_kind = "move"
            if not self.control.moveL(
                target.tolist(), self.args.ur_vel * self.args.k_vel,
                self.args.ur_acc * self.args.k_acc, True,
            ):
                self.control.stopL(float(self.args.stop_deceleration))
                self._motion_kind = None
                raise RuntimeError(f"RTDE rejected moveL: {label}")
        deadline = time.monotonic() + self.args.move_timeout
        saw_running = False
        arrival_deadline = None
        while time.monotonic() < deadline:
            if self.shutdown_event.is_set():
                logging.warning("Arm move interrupted during shutdown: %s", label)
                self.stop_servo()
                return False
            with self._control_lock:
                # A home/quit action can stop this async move while we wait.
                if self._motion_kind != "move":
                    logging.warning("Arm move cancelled before arrival: %s", label)
                    return False
                progress = self.control.getAsyncOperationProgress()
                saw_running = saw_running or progress >= 0
                completed = progress < 0 and (saw_running or progress != previous_progress)
            if completed and self._arrived(target):
                with self._control_lock:
                    self._motion_kind = None
                logging.info("Arm arrived at %s", label)
                return True
            if completed:
                # Control completion and TCP feedback come from separate RTDE
                # interfaces. Allow feedback to catch up before failing the
                # waypoint and abandoning the rest of the return sequence.
                now = time.monotonic()
                if arrival_deadline is None:
                    arrival_deadline = min(
                        deadline, now + self.args.arrival_settle_timeout,
                    )
                    logging.info("Waiting for TCP arrival confirmation at %s", label)
                if now >= arrival_deadline:
                    logging.error(
                        "RTDE move ended without confirmed arrival at %s: target=%s actual=%s",
                        label, target, self.get_tcp_pose(),
                    )
                    self.stop_servo()
                    return False
            self.shutdown_event.wait(0.02)
        logging.error("Arm move timed out at %s: target=%s actual=%s",
                      label, target, self.get_tcp_pose())
        self.stop_servo()
        return False

    def go_to_start(self, release_vacuum: bool = False) -> bool:
        ok = self.move_and_wait(self.waypoints["start"], "initial/start")
        if ok and release_vacuum:
            self.set_vacuum(False)
        return ok

    def pick_from_roi_and_place(self, contact_target: np.ndarray) -> bool:
        """Move once to the frozen predicted contact pose, then pick and place.

        Continuous visual servoing is deliberately stopped before the contact
        move.  This follows ``main copy 2.py``: the servo is only used to bring
        the arm into the camera ROI; the final interception is a standard,
        deterministic ``movel`` to one frozen Kalman prediction.
        """
        place_target = np.asarray(self.waypoints["place"], dtype=np.float64).copy()
        place_target[2] += self.completed_place_count * PLACE_LAYER_STEP_M
        if (
            not np.all(np.isfinite(place_target))
            or np.any(place_target[:3] < np.asarray(self.args.workspace_min))
            or np.any(place_target[:3] > np.asarray(self.args.workspace_max))
        ):
            logging.error("Stacked place target outside workspace: %s", place_target)
            return False
        logging.info(
            "Place layer %d: Z=%.5f m (step %.3f m)",
            self.completed_place_count + 1, place_target[2], PLACE_LAYER_STEP_M,
        )
        # End servo mode before the frozen-target moveL on the same RTDE script.
        self.stop_servo(send_stop=False)
        if not self.move_and_wait(contact_target, "ROI-entry predicted suction pose"):
            return False
        self.set_vacuum(True)
        time.sleep(self.args.vacuum_dwell)

        actual = self.get_tcp_pose()
        lift = contact_target.copy() if actual is None else actual.copy()
        lift[2] += self.args.post_grasp_lift
        if not self.move_and_wait(lift, "post-grasp lift"):
            return False
        if not self.move_and_wait(self.waypoints["middle1"], "middle pose 1 with object"):
            return False
        if not self.move_and_wait(self.waypoints["middle2"], "middle pose 2 with object"):
            return False
        if not self.move_and_wait(place_target, "place pose"):
            return False
        self.set_vacuum(False)
        # The object has been released even if a later return move fails.
        self.completed_place_count += 1
        time.sleep(self.args.release_dwell)
        logging.info("Place layer %d released; returning via middle2 -> middle1",
                     self.completed_place_count)
        if not self.move_and_wait(self.waypoints["middle2"], "middle pose 2 after place"):
            logging.error("Return incomplete at middle2; middle1 has not been reached")
            return False
        if not self.move_and_wait(self.waypoints["middle1"], "middle pose 1 after place"):
            logging.error("Return incomplete at middle1")
            return False
        logging.info("Place layer %d return complete at middle1", self.completed_place_count)
        return True

    @property
    def servo_active(self) -> bool:
        return self._servo_thread is not None and self._servo_thread.is_alive()

    def start_servo(self):
        if self.servo_active:
            return
        actual = self.get_tcp_pose()
        if actual is None:
            raise RuntimeError("Cannot start servo without a valid RTDE TCP pose")
        self._servo_pose = actual.copy()
        with self._target_lock:
            self._servo_target = actual.copy()
            self._last_target_update_time = 0.0
        self._servo_velocity.fill(0.0)
        self._servo_angular_velocity.fill(0.0)
        self.servo_error = None
        self._servo_stop.clear()
        self._servo_thread = threading.Thread(
            target=self._servo_loop,
            name="right-arm-suction-servo",
            daemon=True,
        )
        self._servo_thread.start()
        logging.info("Right-arm RTDE servoL started at %.1f Hz", self.args.servo_rate)

    def update_servo_target(self, target: np.ndarray) -> bool:
        """Publish a vision goal; the independent RTDE loop smooths it at 125 Hz."""
        target = np.asarray(target, dtype=np.float64).reshape(6)
        if not np.all(np.isfinite(target)):
            raise ValueError("Non-finite servo target")
        R_target, _ = cv2.Rodrigues(target[3:])
        if float(R_target[:, 2] @ np.array([0.0, 0.0, -1.0])) < 0.999:
            raise ValueError("Rejected target whose TCP +Z is not downward")
        now = time.monotonic()
        with self._target_lock:
            if now - self._last_target_update_time < self.args.target_update_interval:
                return False
            if self._servo_target is not None:
                pos_delta = float(np.linalg.norm(target[:3] - self._servo_target[:3]))
                R_previous, _ = cv2.Rodrigues(self._servo_target[3:])
                relative = R_target @ R_previous.T
                relative_rvec, _ = cv2.Rodrigues(relative)
                rot_delta = float(np.linalg.norm(relative_rvec))
                if (
                    pos_delta < self.args.target_pos_threshold
                    and rot_delta < self.args.target_rot_threshold
                ):
                    return False
            self._servo_target = target.copy()
            self._last_target_update_time = now
        return True

    def _servo_loop(self):
        period = 1.0 / float(self.args.servo_rate)
        late_cycles = 0
        next_report = time.monotonic() + 5.0
        try:
            while not self._servo_stop.is_set():
                started = time.perf_counter()
                with self._control_lock:
                    cycle_start = self.control.initPeriod()
                with self._target_lock:
                    target = None if self._servo_target is None else self._servo_target.copy()
                current = None if self._servo_pose is None else self._servo_pose.copy()
                if target is not None and current is not None:
                    alpha = float(self.args.servo_alpha)
                    self._servo_velocity = _smooth_servo_velocity(
                        target[:3] - current[:3], self._servo_velocity, period,
                        alpha, float(self.args.max_cart_speed), float(self.args.max_cart_accel),
                    )
                    current[:3] += self._servo_velocity * period

                    R_current, _ = cv2.Rodrigues(current[3:])
                    R_target, _ = cv2.Rodrigues(target[3:])
                    angular_error_rvec, _ = cv2.Rodrigues(R_target @ R_current.T)
                    self._servo_angular_velocity = _smooth_servo_velocity(
                        angular_error_rvec.ravel(), self._servo_angular_velocity, period,
                        alpha, float(self.args.max_angular_speed), float(self.args.max_angular_accel),
                    )
                    R_step, _ = cv2.Rodrigues(self._servo_angular_velocity * period)
                    current[3:] = cv2.Rodrigues(R_step @ R_current)[0].ravel()
                    self._servo_pose = current
                    if (
                        not np.all(np.isfinite(current))
                        or np.any(current[:3] < np.asarray(self.args.workspace_min))
                        or np.any(current[:3] > np.asarray(self.args.workspace_max))
                    ):
                        raise ValueError("Smoothed servo setpoint is outside the workspace")
                    with self._control_lock:
                        if self._servo_stop.is_set():
                            break
                        self._motion_kind = "servo"
                        # speed/acceleration arguments are unused by servoL;
                        # the bounds are enforced above on every setpoint.
                        if not self.control.servoL(
                            current.tolist(), 0.0, 0.0, period,
                            float(self.args.servo_lookahead), int(self.args.servo_gain),
                        ):
                            raise RuntimeError("RTDE servoL rejected the target")
                with self._control_lock:
                    self.control.waitPeriod(cycle_start)
                if time.perf_counter() - started > 1.5 * period:
                    late_cycles += 1
                if time.monotonic() >= next_report:
                    if late_cycles:
                        logging.warning("RTDE servo timing: %d cycles exceeded %.1f ms in 5 s",
                                        late_cycles, 1500.0 * period)
                    late_cycles = 0
                    next_report = time.monotonic() + 5.0
        except BaseException as exc:
            self.servo_error = exc
            logging.exception("Visual-servo thread failed")
            self._servo_stop.set()
        finally:
            # Always leave servo mode, including failures and ROI hand-off.
            try:
                with self._control_lock:
                    if self._motion_kind == "servo":
                        if not self.control.servoStop(float(self.args.stop_deceleration)):
                            raise RuntimeError("RTDE servoStop failed")
                        self._motion_kind = None
            except Exception as exc:
                self.servo_error = exc
                logging.exception("Failed to leave RTDE servo mode")

    def stop_servo(self, send_stop: bool = True):
        thread = self._servo_thread
        self._servo_stop.set()
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=2.0)
            if thread.is_alive():
                raise RuntimeError("RTDE servo thread did not stop; refusing motion hand-off")
        self._servo_thread = None
        with self._control_lock:
            if self._motion_kind == "servo":
                # Do not dispatch moveL if servoStop failed in the worker.
                if not self.control.servoStop(float(self.args.stop_deceleration)):
                    raise RuntimeError("RTDE servoStop failed; refusing motion hand-off")
                self._motion_kind = None
            elif send_stop and self._motion_kind == "move":
                self.control.stopL(float(self.args.stop_deceleration))
                self._motion_kind = None
        if thread is not None:
            logging.info("Right-arm RTDE visual servo stopped")

    def close(self):
        self.shutdown_event.set()
        try:
            self.stop_servo()
            with self._control_lock:
                self.control.stopScript()
        finally:
            for interface in (self.io, self.control, self.rtde):
                try:
                    interface.disconnect()
                except Exception:
                    logging.exception("Failed to disconnect RTDE interface")


class ArmCommandThread(threading.Thread):
    """Serialize blocking waypoint and pick/place operations."""

    def __init__(self, controller: SuctionArmController):
        super().__init__(name="right-arm-command", daemon=True)
        self.controller = controller
        self.commands: queue.Queue[tuple[str, np.ndarray | None] | None] = queue.Queue()
        self.done = threading.Event()
        self.done.set()
        self.last_success = True
        self.last_command = ""

    @property
    def busy(self) -> bool:
        return not self.done.is_set()

    def dispatch(self, command: str, arg: np.ndarray | None = None) -> bool:
        if self.busy:
            return False
        self.done.clear()
        self.commands.put((command, None if arg is None else arg.copy()))
        return True

    def run(self):
        while True:
            item = self.commands.get()
            if item is None:
                return
            command, arg = item
            self.last_command = command
            try:
                if command == "initialize":
                    self.controller.set_vacuum(False)
                    self.last_success = self.controller.go_to_start(False)
                elif command == "home":
                    self.last_success = self.controller.go_to_start(False)
                elif command == "roi_pick" and arg is not None:
                    self.last_success = self.controller.pick_from_roi_and_place(arg)
                else:
                    raise ValueError(f"Unknown arm command: {command}")
            except BaseException:
                self.last_success = False
                logging.exception("Arm command failed: %s", command)
                try:
                    self.controller.stop_servo()
                except Exception:
                    logging.exception("Failed to stop motion after arm command failure")
            finally:
                self.done.set()

    def stop(self):
        self.controller.shutdown_event.set()
        try:
            self.controller.stop_servo()
        finally:
            self.commands.put(None)


BRIDGE_HYPOTHESIS_COUNT = 5


class OpenCVKeyPump(threading.Thread):
    """Own the OpenCV window and latch keys independently of slow inference.

    FoundationPose may take much longer than a key tap to process one frame.
    Calling ``waitKey(1)`` only once per inference frame therefore misses short
    presses.  This thread pumps HighGUI at about 100 Hz and stores every key in
    a queue until the tracking loop consumes it.  A grasp key is latched once
    for the entire cycle; releasing it never cancels robot motion.
    """

    def __init__(self, window: str, width: int, height: int):
        super().__init__(name="opencv-key-pump", daemon=True)
        self.window = window
        self.width = int(width)
        self.height = int(height)
        self._image_lock = threading.Lock()
        self._latest_image: np.ndarray | None = None
        self._key_lock = threading.Lock()
        self._keys: deque[int] = deque()
        self._grasp_latched = False
        self._stop_event = threading.Event()
        self.error: BaseException | None = None

    def submit(self, image_bgr: np.ndarray):
        with self._image_lock:
            self._latest_image = image_bgr

    def latch_key(self, raw_key: int):
        """Retain recognised commands and ignore G repeats until cycle end."""
        if raw_key < 0:
            return
        key = raw_key & 0xFF
        if ord("A") <= key <= ord("Z"):
            key += ord("a") - ord("A")
        if key not in (27, ord("q"), ord("h"), ord("m"), ord("g"), ord("v")):
            return
        with self._key_lock:
            if key == ord("g"):
                if self._grasp_latched:
                    return
                self._grasp_latched = True
                logging.info("G captured: one grasp latched; the key can be released")
            if key not in self._keys:
                self._keys.append(key)

    def set_grasp_active(self, active: bool):
        with self._key_lock:
            # A key captured just after pop_key must remain latched until read.
            self._grasp_latched = bool(active) or ord("g") in self._keys

    def pop_key(self) -> int:
        """Consume one command without losing G to later unrelated keys."""
        with self._key_lock:
            # Cancel/quit wins over queued motion requests.  Clear them so a
            # stale G cannot restart motion after home or re-registration.
            for key in (27, ord("q"), ord("h"), ord("m")):
                if key in self._keys:
                    self._keys.clear()
                    return key
            return self._keys.popleft() if self._keys else -1

    def run(self):
        try:
            cv2.namedWindow(self.window, cv2.WINDOW_NORMAL)
            cv2.resizeWindow(self.window, self.width, self.height)
            logging.info("OpenCV key latch active at 100 Hz")
            while not self._stop_event.is_set():
                with self._image_lock:
                    image = self._latest_image
                    self._latest_image = None
                if image is not None:
                    cv2.imshow(self.window, image)
                self.latch_key(cv2.waitKey(10))
        except BaseException as exc:
            self.error = exc
            logging.exception("OpenCV window/key thread failed")
        finally:
            try:
                cv2.destroyWindow(self.window)
            except Exception:
                pass

    def close(self):
        self._stop_event.set()
        self.join(timeout=2.0)


class LatestFrameSource:
    """Continuously capture frames and expose only the newest one.

    Registration can take much longer than a camera period.  Keeping capture
    in a producer thread prevents the post-registration tracker from consuming
    a stale queue of frames.
    """

    def __init__(self, camera: RealSenseCameraReader):
        self.camera = camera
        self._condition = threading.Condition()
        self._latest: tuple[int, np.ndarray, np.ndarray, float] | None = None
        self._sequence = 0
        self._running = False
        self._error: BaseException | None = None
        self._thread: threading.Thread | None = None

    def start(self):
        self._running = True
        self._thread = threading.Thread(
            target=self._capture_loop,
            name="realsense-latest-frame",
            daemon=True,
        )
        self._thread.start()

    def _capture_loop(self):
        try:
            while self._running:
                result = self.camera.get_frame(timeout_ms=1000)
                if result is None:
                    continue
                color, depth, timestamp = result
                with self._condition:
                    self._sequence += 1
                    self._latest = (
                        self._sequence,
                        color.copy(),
                        depth.copy(),
                        float(timestamp),
                    )
                    self._condition.notify_all()
        except BaseException as exc:  # propagate camera-thread failures
            with self._condition:
                self._error = exc
                self._condition.notify_all()

    def wait_next(
        self,
        after_sequence: int,
        timeout: float = 5.0,
    ) -> tuple[int, np.ndarray, np.ndarray, float] | None:
        deadline = time.monotonic() + timeout
        with self._condition:
            while self._running:
                if self._error is not None:
                    raise RuntimeError("Camera capture thread failed") from self._error
                if self._latest is not None and self._latest[0] > after_sequence:
                    return self._latest
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return None
                self._condition.wait(remaining)
        return None

    def stop(self):
        self._running = False
        with self._condition:
            self._condition.notify_all()
        self.camera.stop()
        if self._thread is not None:
            self._thread.join(timeout=2.0)


class MotionHistorySampler:
    """Collect lightweight 3D mask centres while registration is blocking.

    The sampler observes ``LatestFrameSource`` from a second worker thread and
    stores only ``(camera_timestamp, centre_xyz)`` pairs, never full images.
    Sampling is enabled only from the start of registration until the one-time
    bridge succeeds, so steady-state tracking pays no mask-generation cost.
    """

    def __init__(
        self,
        source: LatestFrameSource,
        center_extractor: Callable[
            [np.ndarray, np.ndarray], tuple[np.ndarray | None, int]
        ],
        max_samples: int = 120,
    ):
        self.source = source
        self.center_extractor = center_extractor
        self._samples: deque[tuple[float, np.ndarray]] = deque(
            maxlen=max(2, int(max_samples))
        )
        self._lock = threading.Lock()
        self._enabled = threading.Event()
        self._running = False
        self._thread: threading.Thread | None = None
        self._epoch = 0
        self._sequence = 0

    def start(self):
        self._running = True
        self._thread = threading.Thread(
            target=self._sampling_loop,
            name="registration-motion-history",
            daemon=True,
        )
        self._thread.start()

    def reset(self, timestamp: float, center: np.ndarray):
        """Start a new registration history with its source-frame centre."""
        with self._lock:
            self._epoch += 1
            self._samples.clear()
            self._append_locked(timestamp, center)
        self._enabled.set()

    def add_sample(self, timestamp: float, center: np.ndarray):
        """Add a centre measured by the main bridge loop."""
        with self._lock:
            self._append_locked(timestamp, center)

    def _append_locked(self, timestamp: float, center: np.ndarray):
        center = np.asarray(center, dtype=np.float64).reshape(3)
        if not np.isfinite(center).all() or not np.isfinite(timestamp):
            return
        if self._samples and timestamp <= self._samples[-1][0] + 1e-6:
            if abs(timestamp - self._samples[-1][0]) <= 1e-6:
                self._samples[-1] = (float(timestamp), center.copy())
            return
        self._samples.append((float(timestamp), center.copy()))

    def snapshot(self) -> list[tuple[float, np.ndarray]]:
        with self._lock:
            return [(timestamp, center.copy()) for timestamp, center in self._samples]

    def disable(self):
        self._enabled.clear()

    def stop(self):
        self._running = False
        self._enabled.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)

    def _sampling_loop(self):
        while self._running:
            if not self._enabled.wait(timeout=0.1):
                continue
            if not self._running:
                break

            with self._lock:
                epoch = self._epoch
            try:
                frame = self.source.wait_next(self._sequence, timeout=0.5)
            except Exception as exc:
                if self._running:
                    logging.error("Motion-history frame source failed: %s", exc)
                break
            if frame is None:
                continue
            sequence, color, depth, timestamp = frame
            self._sequence = sequence

            # ``disable`` may have been called while wait_next was blocked.
            # Avoid starting another mask extraction after bridge hand-off.
            with self._lock:
                if not self._enabled.is_set() or epoch != self._epoch:
                    continue

            try:
                center, mask_pixels = self.center_extractor(color, depth)
            except Exception as exc:
                logging.warning("Motion-history mask sampling failed: %s", exc)
                continue
            if center is None or mask_pixels <= 0:
                continue

            with self._lock:
                if self._enabled.is_set() and epoch == self._epoch:
                    self._append_locked(timestamp, center)


class ProjectionMaskScorer:
    """Score original-CAD poses against an image mask using mask IoU."""

    def __init__(
        self,
        mesh: trimesh.Trimesh,
        K: np.ndarray,
        height: int,
        width: int,
        backend: str = "auto",
    ):
        self.mesh = mesh
        self.K = K
        self.height = height
        self.width = width
        self.backend = backend
        self.renderer = None

        if backend != "hull":
            try:
                from offscreen_renderer import ModelRendererOffscreen

                self.renderer = ModelRendererOffscreen(
                    cam_K=K,
                    H=height,
                    W=width,
                    zfar=10.0,
                )
                logging.info("Bridge mask scorer: CAD renderer")
            except Exception as exc:
                if backend == "renderer":
                    raise RuntimeError(
                        "Requested renderer mask backend is unavailable"
                    ) from exc
                logging.warning(
                    "CAD renderer unavailable; using projected convex hull: %s",
                    exc,
                )

    @staticmethod
    def iou(a: np.ndarray, b: np.ndarray) -> float:
        a = np.asarray(a, dtype=bool)
        b = np.asarray(b, dtype=bool)
        union = np.logical_or(a, b).sum()
        if union == 0:
            return 0.0
        return float(np.logical_and(a, b).sum() / union)

    def project_mask(self, pose: np.ndarray) -> np.ndarray:
        if self.renderer is not None:
            try:
                _, rendered_depth = self.renderer.render(
                    mesh=self.mesh,
                    ob_in_cvcam=pose,
                )
                return (rendered_depth > 0).astype(np.uint8)
            except Exception as exc:
                if self.backend == "renderer":
                    raise
                logging.warning(
                    "CAD rendering failed; switching to convex hull: %s",
                    exc,
                )
                self._close_renderer()
        return self._project_hull(pose)

    def score(
        self,
        pose: np.ndarray,
        target_mask: np.ndarray,
    ) -> tuple[float, np.ndarray]:
        projected = self.project_mask(pose)
        return self.iou(projected, target_mask), projected

    def _project_hull(self, pose: np.ndarray) -> np.ndarray:
        vertices = np.asarray(self.mesh.vertices)
        vertices_h = np.concatenate(
            [vertices, np.ones((len(vertices), 1))],
            axis=1,
        )
        points = (pose @ vertices_h.T).T[:, :3]
        valid = points[:, 2] > 1e-6
        mask = np.zeros((self.height, self.width), dtype=np.uint8)
        if valid.sum() < 3:
            return mask

        uvw = (self.K @ points[valid].T).T
        uv = uvw[:, :2] / uvw[:, 2:3]
        inside = (
            (uv[:, 0] >= 0)
            & (uv[:, 0] < self.width)
            & (uv[:, 1] >= 0)
            & (uv[:, 1] < self.height)
        )
        uv = uv[inside]
        if len(uv) < 3:
            return mask
        hull = cv2.convexHull(uv.astype(np.float32)).astype(np.int32)
        cv2.fillConvexPoly(mask, hull, 1)
        return mask

    def _close_renderer(self):
        if self.renderer is None:
            return
        try:
            self.renderer.r.delete()
        except Exception:
            pass
        self.renderer = None

    def close(self):
        self._close_renderer()


def _setup_logging(log_path: str):
    handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    logging.getLogger().addHandler(handler)


def _apply_mask_params(args, saved: dict | None):
    if not saved:
        return
    for name in (
        "fg_offset",
        "silver_s_max",
        "min_area",
        "max_area",
        "morph_kernel",
        "depth_min",
        "depth_max",
    ):
        if name in saved:
            setattr(args, name, type(getattr(args, name))(saved[name]))


def _compute_mask(args, color, depth, roi) -> np.ndarray:
    result = compute_mask(
        color,
        depth,
        roi,
        fg_offset=args.fg_offset,
        silver_s_max=args.silver_s_max,
        min_area=args.min_area,
        max_area=args.max_area,
        morph_kernel=args.morph_kernel,
        depth_min=args.depth_min,
        depth_max=args.depth_max,
    )
    return result["mask"].astype(bool)


def _mask_center_3d(
    mask: np.ndarray,
    depth: np.ndarray,
    K: np.ndarray,
) -> np.ndarray | None:
    """Estimate the mask's camera-frame 3D centre using median depth."""
    rows, cols = np.where(mask)
    valid = mask & np.isfinite(depth) & (depth >= 0.001)
    if len(cols) == 0 or valid.sum() < 4:
        return None
    u = 0.5 * (float(cols.min()) + float(cols.max()))
    v = 0.5 * (float(rows.min()) + float(rows.max()))
    z = float(np.median(depth[valid]))
    return (np.linalg.inv(K) @ np.array([u, v, 1.0])) * z


def _pose_with_centered_translation(
    pose_original: np.ndarray,
    centered_translation: np.ndarray,
    tf_to_center: np.ndarray,
) -> np.ndarray:
    """Move an original-CAD pose so its centered mesh reaches a 3D point."""
    centered_pose = pose_original @ np.linalg.inv(tf_to_center)
    centered_pose[:3, 3] = centered_translation
    return centered_pose @ tf_to_center


def _dedupe_poses(poses: list[np.ndarray]) -> list[np.ndarray]:
    unique: list[np.ndarray] = []
    keys: set[tuple[float, ...]] = set()
    for pose in poses:
        pose = np.asarray(pose, dtype=np.float64).reshape(4, 4)
        key = tuple(np.round(pose[:3, :].reshape(-1), 6))
        if key in keys:
            continue
        keys.add(key)
        unique.append(pose.copy())
    return unique


def _belt_velocity_from_args(args) -> np.ndarray | None:
    """Return configured belt velocity in camera coordinates, if supplied."""
    if args.belt_speed <= 0.0:
        return None
    direction = np.asarray(args.belt_direction, dtype=np.float64).reshape(3)
    norm = float(np.linalg.norm(direction))
    if norm < 1e-9:
        raise ValueError("--belt_direction must be non-zero")
    return direction / norm * float(args.belt_speed)


def _translate_pose(pose: np.ndarray, delta: np.ndarray) -> np.ndarray:
    shifted = np.asarray(pose, dtype=np.float64).reshape(4, 4).copy()
    shifted[:3, 3] += np.asarray(delta, dtype=np.float64).reshape(3)
    return shifted


def _build_bridge_candidates(
    kalman: PoseKalmanFilter,
    registration_pose: np.ndarray,
    registration_mask_center: np.ndarray,
    current_mask_center: np.ndarray,
    velocity: np.ndarray,
    tf_to_center: np.ndarray,
    registration_timestamp: float,
    current_timestamp: float,
    args,
) -> tuple[list[np.ndarray], dict[str, float | np.ndarray]]:
    """Predict the registration pose to now and build five bridge priors."""
    registration_centered = (
        np.asarray(registration_pose).reshape(4, 4)
        @ np.linalg.inv(tf_to_center)
    )
    # Preserve the registration-time offset between the mask bounding-box
    # centre and the actual CAD centre instead of assuming they are identical.
    mask_to_model_offset = (
        registration_centered[:3, 3] - registration_mask_center
    )
    current_model_center = current_mask_center + mask_to_model_offset
    mask_anchor = _pose_with_centered_translation(
        registration_pose,
        current_model_center,
        tf_to_center,
    )

    velocity = np.asarray(velocity, dtype=np.float64).reshape(3)
    kalman.initialize(
        registration_pose,
        registration_timestamp,
        velocity=velocity,
    )
    prediction_dt = max(current_timestamp - registration_timestamp, 0.0)
    predicted = kalman.predict(prediction_dt)
    kalman.update(mask_anchor, current_timestamp)
    filtered = kalman.get_current_pose()

    speed = float(np.linalg.norm(velocity))
    displacement = current_mask_center - registration_mask_center
    if speed > 1e-8:
        motion_direction = velocity / speed
    elif np.linalg.norm(displacement) > 1e-8:
        motion_direction = displacement / np.linalg.norm(displacement)
    else:
        motion_direction = np.asarray(
            args.belt_direction, dtype=np.float64,
        ).reshape(3)
        direction_norm = float(np.linalg.norm(motion_direction))
        if direction_norm < 1e-9:
            motion_direction = np.array([1.0, 0.0, 0.0])
        else:
            motion_direction = motion_direction / direction_norm

    step = max(float(args.hyp_translation_step), 0.0)
    ordered = [
        predicted,
        mask_anchor,
        filtered,
        _translate_pose(predicted, -step * motion_direction),
        _translate_pose(predicted, step * motion_direction),
    ]
    unique = _dedupe_poses(ordered)
    # Degenerate zero-motion cases can deduplicate candidates. Fill any open
    # slots with small camera-axis translations while retaining the five-pose
    # computation budget requested for online use.
    for axis in np.eye(3):
        for sign in (-1.0, 1.0):
            if len(unique) >= BRIDGE_HYPOTHESIS_COUNT:
                break
            unique = _dedupe_poses(
                unique + [_translate_pose(predicted, sign * step * axis)]
            )
        if len(unique) >= BRIDGE_HYPOTHESIS_COUNT:
            break

    unique = unique[:BRIDGE_HYPOTHESIS_COUNT]
    if len(unique) != BRIDGE_HYPOTHESIS_COUNT:
        raise RuntimeError(
            "Could not construct exactly five distinct bridge hypotheses"
        )

    return unique, {
        "prediction_dt": prediction_dt,
        "velocity": velocity.copy(),
        "speed": speed,
        "mask_displacement": displacement.copy(),
    }


def _mask_overlay(
    color_rgb: np.ndarray,
    target_mask: np.ndarray,
    projected_mask: np.ndarray,
) -> np.ndarray:
    overlay = np.zeros_like(color_rgb)
    target = target_mask.astype(bool)
    projected = projected_mask.astype(bool)
    overlay[target] = [0, 255, 0]
    overlay[projected] = [255, 0, 0]
    overlay[target & projected] = [255, 255, 0]
    return cv2.addWeighted(color_rgb, 0.65, overlay, 0.35, 0.0)


def _draw_pose(
    color_rgb: np.ndarray,
    K: np.ndarray,
    pose_original: np.ndarray,
    to_origin_inv: np.ndarray,
    bbox: np.ndarray,
) -> np.ndarray:
    center_pose = pose_original @ to_origin_inv
    vis = draw_posed_3d_box(
        K,
        img=color_rgb.copy(),
        ob_in_cam=center_pose,
        bbox=bbox,
    )
    return draw_xyz_axis(
        vis,
        ob_in_cam=center_pose,
        scale=0.1,
        K=K,
        thickness=3,
        transparency=0,
        is_input_rgb=True,
    )


def _draw_status(
    image_rgb: np.ndarray,
    state: TrackingState,
    frame_index: int,
    fps: float,
    detail: str,
) -> np.ndarray:
    vis = image_rgb.copy()
    colors = {
        TrackingState.WAITING_MASK: (255, 255, 0),
        TrackingState.REGISTERING: (255, 128, 0),
        TrackingState.BRIDGING: (255, 0, 255),
        TrackingState.TRACKING: (0, 255, 0),
    }
    color = colors[state]
    cv2.putText(
        vis,
        f"[{state.value.upper()}] frame={frame_index} fps={fps:.1f}",
        (10, 25),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        color,
        2,
        cv2.LINE_AA,
    )
    if detail:
        cv2.putText(
            vis,
            detail,
            (10, 50),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            color,
            1,
            cv2.LINE_AA,
        )
    return vis


def run(args):
    mesh = trimesh.load(args.mesh_file)
    to_origin, extents = trimesh.bounds.oriented_bounds(mesh)
    to_origin_inv = np.linalg.inv(to_origin)
    bbox = np.stack([-extents / 2, extents / 2], axis=0).reshape(2, 3)

    scorer = ScorePredictor()
    refiner = PoseRefinePredictor()
    glctx = dr.RasterizeCudaContext()
    estimator = FoundationPose(
        model_pts=mesh.vertices,
        model_normals=mesh.vertex_normals,
        mesh=mesh,
        scorer=scorer,
        refiner=refiner,
        debug_dir=args.debug_dir,
        debug=args.debug,
        glctx=glctx,
    )

    roi = load_roi_config(args.roi_config)
    _apply_mask_params(args, load_mask_params(args.roi_config))
    if roi is None:
        logging.warning("No valid ROI; mask generation will use the full image")

    T_cam_to_base = load_calibration(args.calib)
    if not np.allclose(T_cam_to_base[3], [0.0, 0.0, 0.0, 1.0], atol=1e-8):
        raise ValueError("--calib must contain a homogeneous camera-to-base matrix")
    model_vertices = np.asarray(mesh.vertices, dtype=np.float64)

    camera = RealSenseCameraReader(args.cam_width, args.cam_height, args.cam_fps)
    K = camera.get_intrinsics()
    source = LatestFrameSource(camera)

    def extract_motion_center(
        color_rgb: np.ndarray,
        depth_m: np.ndarray,
    ) -> tuple[np.ndarray | None, int]:
        sampled_mask = _compute_mask(args, color_rgb, depth_m, roi)
        pixel_count = int(sampled_mask.sum())
        if pixel_count < args.min_mask_pixels:
            return None, pixel_count
        return _mask_center_3d(sampled_mask, depth_m, K), pixel_count

    motion_sampler = MotionHistorySampler(
        source,
        extract_motion_center,
        max_samples=args.motion_history_size,
    )
    tf_to_center = estimator.get_tf_to_centered_mesh().data.cpu().numpy()
    try:
        mask_scorer = ProjectionMaskScorer(
            mesh,
            K,
            args.cam_height,
            args.cam_width,
            backend=args.mask_score_backend,
        )
    except Exception:
        camera.stop()
        raise

    os.makedirs(args.debug_dir, exist_ok=True)
    pose_dir = os.path.join(args.debug_dir, "ob_in_cam")
    if args.save_poses:
        os.makedirs(pose_dir, exist_ok=True)

    state = TrackingState.WAITING_MASK
    sequence = 0
    frame_index = 0
    registration_pose: np.ndarray | None = None
    registration_timestamp: float | None = None
    registration_mask_center: np.ndarray | None = None
    kalman: PoseKalmanFilter | None = None
    bridge_attempts = 0
    current_pose: np.ndarray | None = None
    bridge_velocity = np.zeros(3)
    bridge_pose_timestamp: float | None = None
    first_native_prediction_pending = False
    fps_ema = 0.0
    detail = ""
    arm: SuctionArmController | None = None
    arm_thread: ArmCommandThread | None = None
    rtde = None
    rtde_control_client = None
    rtde_io_client = None
    grasp_state = GraspState.IDLE
    last_arm_target: np.ndarray | None = None
    last_arm_error = float("nan")
    last_tcp_uv: tuple[int, int] | None = None
    auto_grasp_started = False
    grasp_requested = False
    grasp_request_source = ""
    last_grasp_wait_reason = ""
    window = "Online Suction Pick (g=grab h=home v=vacuum m=re-register q=quit)"
    display: OpenCVKeyPump | None = None
    if not args.no_show:
        display = OpenCVKeyPump(window, args.window_width, args.window_height)
        display.start()

    try:
        if not args.no_arm:
            if args.tool_height is None:
                raise ValueError(
                    "--tool_height is required when the arm is enabled; "
                    "use --no_arm for vision-only testing"
                )
            waypoints = _load_right_arm_waypoints(args.waypoints_file)
            # Keep a single resident control script for servoL and moveL.
            # Sending standalone URScripts would interrupt that script.
            try:
                import rtde_control
                import rtde_io
            except ImportError as exc:
                raise RuntimeError("Smooth suction control requires the ur-rtde package") from exc
            rtde = _try_connect_rtde(args.ur_host)
            if rtde is None:
                raise ConnectionError(f"Cannot read right-arm RTDE feedback at {args.ur_host}")
            rtde_control_client = rtde_control.RTDEControlInterface(args.ur_host, args.servo_rate)
            rtde_io_client = rtde_io.RTDEIOInterface(args.ur_host)
            arm = SuctionArmController(rtde, rtde_control_client, rtde_io_client, waypoints, args)
            arm.configure_tool()
            logging.info(
                "Arm control revision=%s predict_dt=%.3fs backend=RTDE-servoL "
                "rate=%.1fHz lookahead=%.3fs gain=%d alpha=%.3f max_accel=%.3fm/s^2",
                CONTROL_REVISION,
                args.arm_predict_dt,
                args.servo_rate,
                args.servo_lookahead,
                args.servo_gain,
                args.servo_alpha,
                args.max_cart_accel,
            )
            arm_thread = ArmCommandThread(arm)
            arm_thread.start()
            arm_thread.dispatch("initialize")
            logging.info("Right-arm initialization dispatched")

        source.start()
        motion_sampler.start()
        while args.max_frames <= 0 or frame_index < args.max_frames:
            frame = source.wait_next(sequence, timeout=5.0)
            if frame is None:
                logging.warning("Timed out waiting for a camera frame")
                continue
            sequence, color, depth, timestamp = frame
            frame_index += 1
            started = time.perf_counter()
            projected_mask = None
            target_mask = None

            if state in (TrackingState.WAITING_MASK, TrackingState.REGISTERING):
                state = TrackingState.WAITING_MASK
                target_mask = _compute_mask(args, color, depth, roi)
                initial_mask_center = _mask_center_3d(target_mask, depth, K)
                if (
                    int(target_mask.sum()) < args.min_mask_pixels
                    or initial_mask_center is None
                ):
                    detail = f"mask too small: {int(target_mask.sum())} px"
                else:
                    state = TrackingState.REGISTERING
                    registration_timestamp = timestamp
                    registration_mask_center = initial_mask_center.copy()
                    motion_sampler.reset(timestamp, initial_mask_center)
                    logging.info(
                        "Registering frame=%d timestamp=%.6f mask_pixels=%d",
                        frame_index,
                        timestamp,
                        int(target_mask.sum()),
                    )
                    registration_started = time.perf_counter()
                    registration_pose = estimator.register(
                        K=K,
                        rgb=color,
                        depth=depth,
                        ob_mask=target_mask,
                        iteration=args.est_refine_iter,
                    )
                    registration_wall_time = (
                        time.perf_counter() - registration_started
                    )
                    kalman = PoseKalmanFilter(
                        q_pos=args.q_pos,
                        q_vel=args.q_vel,
                        r_pos=args.r_pos,
                        q_omega=args.q_omega,
                        r_omega=args.r_omega,
                        max_speed=max(args.max_speed, args.belt_speed),
                        vel_deadzone=args.vel_deadzone,
                        warmup_frames=1,
                    )
                    current_pose = registration_pose
                    bridge_attempts = 0
                    state = TrackingState.BRIDGING
                    detail = "registration done; waiting for newest frame"
                    logging.info(
                        "Registration complete in %.3fs; entering one-time "
                        "motion-history bridge",
                        registration_wall_time,
                    )

            elif state == TrackingState.BRIDGING:
                assert (
                    registration_pose is not None
                    and registration_timestamp is not None
                    and registration_mask_center is not None
                    and kalman is not None
                )
                target_mask = _compute_mask(args, color, depth, roi)
                mask_center = _mask_center_3d(target_mask, depth, K)
                if (
                    int(target_mask.sum()) < args.min_mask_pixels
                    or mask_center is None
                ):
                    bridge_attempts += 1
                    detail = (
                        f"bridge mask invalid; attempt "
                        f"{bridge_attempts}/{args.max_bridge_attempts}"
                    )
                else:
                    motion_sampler.add_sample(timestamp, mask_center)
                    samples = [
                        sample
                        for sample in motion_sampler.snapshot()
                        if sample[0] <= timestamp + 1e-6
                    ]
                    configured_velocity = _belt_velocity_from_args(args)
                    if configured_velocity is not None:
                        velocity = configured_velocity
                        velocity_stats = {
                            "samples": len(samples),
                            "inliers": len(samples),
                            "rmse": 0.0,
                        }
                        velocity_source = "configured"
                    else:
                        velocity, velocity_stats = estimate_constant_velocity(
                            samples,
                            max_speed=args.max_speed,
                            outlier_threshold=args.motion_outlier_threshold,
                        )
                        velocity_source = "mask-history"

                    candidates, prediction_info = _build_bridge_candidates(
                        kalman,
                        registration_pose,
                        registration_mask_center,
                        mask_center,
                        velocity,
                        tf_to_center,
                        registration_timestamp,
                        timestamp,
                        args,
                    )
                    refined = estimator.track_hypotheses(
                        rgb=color,
                        depth=depth,
                        K=K,
                        ob_in_cam_hypotheses=candidates,
                        iteration=args.bridge_refine_iter,
                    )

                    scores: list[float] = []
                    masks: list[np.ndarray] = []
                    for pose in refined:
                        score, candidate_mask = mask_scorer.score(
                            pose,
                            target_mask,
                        )
                        scores.append(score)
                        masks.append(candidate_mask)

                    best_index = int(np.argmax(scores))
                    best_iou = float(scores[best_index])
                    projected_mask = masks[best_index]
                    bridge_attempts += 1
                    detail = (
                        f"bridge hyp={best_index}/{len(candidates)} "
                        f"IoU={best_iou:.3f} "
                        f"v={prediction_info['speed']:.3f}m/s"
                    )
                    logging.info(
                        "Bridge attempt=%d dt=%.3fs hypotheses=%d best=%d "
                        "IoU=%.4f velocity=%s [%.5f %.5f %.5f]m/s "
                        "samples=%d inliers=%d rmse=%.4fm",
                        bridge_attempts,
                        prediction_info["prediction_dt"],
                        len(candidates),
                        best_index,
                        best_iou,
                        velocity_source,
                        velocity[0],
                        velocity[1],
                        velocity[2],
                        velocity_stats["samples"],
                        velocity_stats["inliers"],
                        velocity_stats["rmse"],
                    )

                    if best_iou >= args.min_mask_iou:
                        current_pose = refined[best_index]
                        estimator.set_pose_last_from_ob_in_cam(current_pose)
                        bridge_velocity = velocity.copy()
                        bridge_pose_timestamp = timestamp
                        first_native_prediction_pending = True
                        motion_sampler.disable()
                        state = TrackingState.TRACKING
                        detail += " -> native tracking"
                        logging.info(
                            "Bridge accepted; mask scoring disabled and grasp "
                            "Kalman retained for steady-state prediction"
                        )

                if (
                    state == TrackingState.BRIDGING
                    and bridge_attempts >= args.max_bridge_attempts
                ):
                    logging.warning(
                        "Bridge failed after %d attempts; re-registering",
                        bridge_attempts,
                    )
                    state = TrackingState.WAITING_MASK
                    motion_sampler.disable()
                    registration_pose = None
                    registration_timestamp = None
                    registration_mask_center = None
                    kalman = None
                    bridge_pose_timestamp = None
                    first_native_prediction_pending = False

            elif state == TrackingState.TRACKING:
                handoff_detail = ""
                if (
                    first_native_prediction_pending
                    and current_pose is not None
                    and bridge_pose_timestamp is not None
                ):
                    handoff_dt = max(timestamp - bridge_pose_timestamp, 0.0)
                    first_track_prior = _translate_pose(
                        current_pose,
                        bridge_velocity * handoff_dt,
                    )
                    estimator.set_pose_last_from_ob_in_cam(first_track_prior)
                    first_native_prediction_pending = False
                    handoff_detail = f" handoff-dt={handoff_dt:.3f}s"
                    logging.info(
                        "First native-frame prior advanced by %.3fs "
                        "([%.5f %.5f %.5f]m)",
                        handoff_dt,
                        *(bridge_velocity * handoff_dt),
                    )
                current_pose = estimator.track_one(
                    rgb=color,
                    depth=depth,
                    K=K,
                    iteration=args.track_refine_iter,
                )
                # Unlike the one-time bridge path, robot interception needs a
                # continuously refreshed velocity estimate.
                assert kalman is not None
                kalman.update(current_pose, timestamp)
                detail = (
                    "native FoundationPose + grasp Kalman"
                    + handoff_detail
                )

            # ---- Follow predicted hover until TCP enters ROI, then one-shot pick ----
            if arm is not None and arm_thread is not None:
                if arm.servo_error is not None and grasp_state == GraspState.FOLLOW_ROI:
                    logging.error("Aborting grasp after servo failure: %s", arm.servo_error)
                    arm.stop_servo()
                    grasp_state = GraspState.IDLE

                if (
                    grasp_state == GraspState.FOLLOW_ROI
                    and state == TrackingState.TRACKING
                    and current_pose is not None
                    and kalman is not None
                ):
                    prediction = kalman.predict(args.arm_predict_dt)
                    arm_target = compute_suction_target(
                        T_cam_to_base,
                        prediction,
                        model_vertices,
                        to_origin_inv,
                        clearance_m=args.approach_clearance,
                        tool_height_m=args.tool_height,
                        tcp_mode=args.tcp_mode,
                        yaw_deg=args.grasp_yaw_deg,
                    )

                    workspace_min = np.asarray(args.workspace_min, dtype=np.float64)
                    workspace_max = np.asarray(args.workspace_max, dtype=np.float64)
                    target_in_workspace = bool(
                        np.all(arm_target[:3] >= workspace_min)
                        and np.all(arm_target[:3] <= workspace_max)
                    )
                    target_jump = (
                        0.0
                        if last_arm_target is None
                        else float(np.linalg.norm(arm_target[:3] - last_arm_target[:3]))
                    )
                    if not target_in_workspace or target_jump > args.max_target_jump:
                        logging.error(
                            "Unsafe servo target rejected: xyz=%s workspace=%s..%s jump=%.3fm",
                            np.array2string(arm_target[:3], precision=4),
                            np.array2string(workspace_min, precision=3),
                            np.array2string(workspace_max, precision=3),
                            target_jump,
                        )
                        arm.stop_servo()
                        grasp_state = GraspState.IDLE
                        last_arm_target = None
                    else:
                        arm.update_servo_target(arm_target)
                        last_arm_target = arm_target.copy()
                        actual_tcp = arm.get_tcp_pose()
                        if actual_tcp is not None:
                            last_arm_error = float(
                                np.linalg.norm(actual_tcp[:3] - arm_target[:3])
                            )
                            last_tcp_uv = project_base_pose_to_image(
                                K, T_cam_to_base, actual_tcp
                            )
                            in_roi = bool(
                                roi is not None
                                and last_tcp_uv is not None
                                and is_point_in_expanded_roi(
                                    last_tcp_uv[0],
                                    last_tcp_uv[1],
                                    roi,
                                    margin=args.arm_roi_margin,
                                )
                            )
                            if in_roi:
                                # Freeze exactly one future contact pose at the
                                # ROI boundary.  No more vision updates are sent
                                # during the final movel or suction operation.
                                contact_prediction = kalman.predict(args.arm_predict_dt)
                                # Select height from this final predicted frame
                                # only.  The frozen target is then dispatched
                                # once; following frames cannot change it.
                                contact_target = compute_suction_target(
                                    T_cam_to_base,
                                    contact_prediction,
                                    model_vertices,
                                    to_origin_inv,
                                    clearance_m=args.contact_clearance,
                                    tool_height_m=args.tool_height,
                                    tcp_mode=args.tcp_mode,
                                    yaw_deg=args.grasp_yaw_deg,
                                    tool_height_z_down_m=args.tool_height_z_down,
                                    tool_height_z_up_m=args.tool_height_z_up,
                                    use_directional_height=True,
                                )
                                # Conveyor contact uses an absolute robot Z.
                                # Override after all height compensation and before
                                # workspace validation / dispatch to the robot.
                                contact_target[2] = FINAL_GRASP_Z_M
                                contact_safe = bool(
                                    np.all(contact_target[:3] >= workspace_min)
                                    and np.all(contact_target[:3] <= workspace_max)
                                )
                                if not contact_safe:
                                    logging.error(
                                        "ROI-entry contact target rejected: xyz=%s workspace=%s..%s",
                                        np.array2string(contact_target[:3], precision=4),
                                        np.array2string(workspace_min, precision=3),
                                        np.array2string(workspace_max, precision=3),
                                    )
                                    arm.stop_servo()
                                    grasp_state = GraspState.IDLE
                                    last_arm_target = None
                                else:
                                    arm.stop_servo(send_stop=False)
                                    if arm_thread.dispatch("roi_pick", contact_target):
                                        grasp_state = GraspState.FINISHING
                                        last_arm_target = contact_target.copy()
                                        logging.info(
                                            "TCP entered ROI at uv=%s; frozen %.2fs prediction xyz=%s; "
                                            "standard movel suction cycle dispatched",
                                            last_tcp_uv,
                                            args.arm_predict_dt,
                                            np.array2string(contact_target[:3], precision=4),
                                        )
                                    else:
                                        logging.error(
                                            "ROI-entry pick was not dispatched because the arm command thread is busy"
                                        )
                                        grasp_state = GraspState.IDLE
                                        last_arm_target = None

                if grasp_state == GraspState.FINISHING and not arm_thread.busy:
                    if arm_thread.last_success:
                        logging.info("Suction pick/place cycle completed")
                    else:
                        logging.error("Suction pick/place cycle failed")
                    grasp_state = GraspState.IDLE
                    last_arm_target = None
                    last_tcp_uv = None

                if args.auto_grasp and not auto_grasp_started:
                    auto_grasp_started = True
                    grasp_requested = True
                    grasp_request_source = "automatic"
                    logging.info(
                        "Automatic grasp request queued; it will start when tracking and arm are ready"
                    )

                if grasp_requested and grasp_state == GraspState.IDLE:
                    wait_reasons: list[str] = []
                    if state != TrackingState.TRACKING:
                        wait_reasons.append(f"tracker={state.value}")
                    if kalman is None:
                        wait_reasons.append("kalman=not-ready")
                    if arm_thread.busy:
                        wait_reasons.append(
                            f"arm-command={arm_thread.last_command or 'initializing'}"
                        )
                    if roi is None:
                        wait_reasons.append("roi=missing")

                    if wait_reasons:
                        wait_reason = ", ".join(wait_reasons)
                        if wait_reason != last_grasp_wait_reason:
                            logging.warning(
                                "%s grasp request is waiting: %s",
                                grasp_request_source.capitalize() or "Queued",
                                wait_reason,
                            )
                            last_grasp_wait_reason = wait_reason
                    else:
                        try:
                            arm.start_servo()
                        except BaseException:
                            grasp_requested = False
                            last_grasp_wait_reason = ""
                            logging.exception("Failed to start predicted visual follow")
                        else:
                            grasp_requested = False
                            last_grasp_wait_reason = ""
                            grasp_state = GraspState.FOLLOW_ROI
                            last_arm_target = None
                            last_tcp_uv = None
                            logging.info(
                                "%s predicted follow started; waiting for TCP to enter ROI",
                                grasp_request_source.capitalize() or "Queued",
                            )

                detail += (
                    f" grasp={grasp_state.value}"
                    + ("" if not np.isfinite(last_arm_error) else f" err={last_arm_error:.3f}m")
                    + ("" if last_tcp_uv is None else f" tcp_uv={last_tcp_uv}")
                    + (
                        ""
                        if not grasp_requested
                        else f" request=waiting({last_grasp_wait_reason or 'checking'})"
                    )
                )

            elapsed = max(time.perf_counter() - started, 1e-9)
            instantaneous_fps = 1.0 / elapsed
            fps_ema = (
                instantaneous_fps
                if fps_ema <= 0.0
                else 0.9 * fps_ema + 0.1 * instantaneous_fps
            )

            if args.save_poses and current_pose is not None:
                np.savetxt(
                    os.path.join(pose_dir, f"{frame_index:06d}.txt"),
                    current_pose,
                )

            key = -1
            if display is not None:
                if current_pose is None:
                    vis = color.copy()
                else:
                    vis = _draw_pose(
                        color,
                        K,
                        current_pose,
                        to_origin_inv,
                        bbox,
                    )
                if target_mask is not None and projected_mask is None:
                    projected_mask = np.zeros_like(target_mask, dtype=np.uint8)
                if target_mask is not None and projected_mask is not None:
                    # Keep one 1280x720-style view, matching main copy 2.py.
                    # During registration/bridging the mask consistency result
                    # is blended directly onto the pose view instead of being
                    # concatenated as a second panel.
                    vis = _mask_overlay(vis, target_mask, projected_mask)
                vis = _draw_status(vis, state, frame_index, fps_ema, detail)
                display.submit(vis[..., ::-1])
                key = display.pop_key()
                if display.error is not None:
                    raise RuntimeError("OpenCV display/key thread stopped") from display.error

            if key in (27, ord("q")):
                break
            if key == ord("m"):
                logging.info("Manual re-registration requested")
                # The dispatched pick/place uses a frozen target and does not
                # depend on live vision. Do not stop its moveL or reset its
                # FINISHING state while registering the next object.
                if grasp_state == GraspState.FINISHING:
                    logging.info(
                        "Re-registering next object; current pick/place/return continues"
                    )
                else:
                    if arm is not None and grasp_state == GraspState.FOLLOW_ROI:
                        # Stop following the obsolete visual target only;
                        # initialization/home moveL commands are independent.
                        arm.stop_servo(send_stop=False)
                    grasp_state = GraspState.IDLE
                grasp_requested = False
                last_grasp_wait_reason = ""
                last_arm_target = None
                last_tcp_uv = None
                state = TrackingState.WAITING_MASK
                motion_sampler.disable()
                registration_pose = None
                registration_timestamp = None
                registration_mask_center = None
                kalman = None
                current_pose = None
                bridge_pose_timestamp = None
                first_native_prediction_pending = False

            elif key in (ord("g"), ord("G")):
                if arm is None or arm_thread is None:
                    logging.error("G key received, but the arm is disabled or not connected")
                elif grasp_state == GraspState.IDLE:
                    grasp_requested = True
                    grasp_request_source = "manual"
                    last_grasp_wait_reason = ""
                    logging.info(
                        "G key accepted: one full grasp cycle queued; no need to hold G"
                    )
                else:
                    logging.warning(
                        "G key ignored because a grasp cycle is already active: grasp=%s arm_busy=%s",
                        grasp_state.value,
                        arm_thread.busy,
                    )

            elif key == ord("h") and arm is not None and arm_thread is not None:
                arm.stop_servo()
                grasp_state = GraspState.IDLE
                grasp_requested = False
                last_grasp_wait_reason = ""
                last_arm_target = None
                last_tcp_uv = None
                if not arm_thread.busy:
                    arm_thread.dispatch("home")
                    logging.info("Return-to-start dispatched; vacuum state preserved")

            elif key == ord("v") and arm is not None:
                arm.set_vacuum(not arm.vacuum_enabled)

            if display is not None:
                display.set_grasp_active(
                    grasp_requested or grasp_state != GraspState.IDLE
                )

    finally:
        if arm_thread is not None:
            try:
                arm_thread.stop()
            except Exception:
                logging.exception("Failed to stop arm worker during shutdown")
            arm_thread.join(timeout=2.0)
        if arm is not None:
            if arm.vacuum_enabled:
                logging.warning(
                    "Program exited while vacuum was ON; output is intentionally preserved "
                    "to avoid dropping a held object"
                )
            try:
                arm.close()
            except Exception:
                logging.exception("Failed to close arm control cleanly")
        else:
            # Also clean up partially connected interfaces if setup failed.
            if rtde_control_client is not None:
                try:
                    rtde_control_client.stopScript()
                except Exception:
                    logging.exception("Failed to stop RTDE script during setup cleanup")
            for interface in (rtde_io_client, rtde_control_client, rtde):
                if interface is not None:
                    try:
                        interface.disconnect()
                    except Exception:
                        logging.exception("Failed to disconnect RTDE during setup cleanup")
        mask_scorer.close()
        motion_sampler.stop()
        source.stop()
        if display is not None:
            display.close()
        else:
            cv2.destroyAllWindows()
        logging.info("Online tracker stopped")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Live FoundationPose with Kalman-predicted right-arm suction "
            "visual servo and pick/place"
        )
    )
    parser.add_argument("--mesh_file", type=str, required=True)
    parser.add_argument(
        "--roi_config",
        type=str,
        default=os.path.join(_code_dir, "roi_config.json"),
    )

    parser.add_argument("--est_refine_iter", type=int, default=3)
    parser.add_argument("--bridge_refine_iter", type=int, default=2)
    parser.add_argument("--track_refine_iter", type=int, default=2)
    parser.add_argument("--debug", type=int, default=1)
    parser.add_argument(
        "--debug_dir",
        type=str,
        default=os.path.join(_code_dir, "debug_online_kalman"),
    )

    parser.add_argument("--cam_width", type=int, default=1280)
    parser.add_argument("--cam_height", type=int, default=720)
    parser.add_argument("--cam_fps", type=int, default=30)
    parser.add_argument(
        "--window_width",
        type=int,
        default=1600,
        help="Online visualisation window width in pixels",
    )
    parser.add_argument(
        "--window_height",
        type=int,
        default=900,
        help="Online visualisation window height in pixels",
    )

    parser.add_argument("--fg_offset", type=int, default=30)
    parser.add_argument("--silver_s_max", type=int, default=100)
    parser.add_argument("--min_area", type=int, default=300)
    parser.add_argument("--max_area", type=int, default=0)
    parser.add_argument("--morph_kernel", type=int, default=5)
    parser.add_argument("--depth_min", type=float, default=0.05)
    parser.add_argument("--depth_max", type=float, default=2.0)
    parser.add_argument("--min_mask_pixels", type=int, default=100)

    # FreeTrack6D real-world defaults (Table 5).
    parser.add_argument("--q_pos", type=float, default=0.002)
    parser.add_argument("--q_vel", type=float, default=0.003)
    parser.add_argument("--r_pos", type=float, default=0.005)
    parser.add_argument("--q_omega", type=float, default=0.02)
    parser.add_argument("--r_omega", type=float, default=0.5)
    parser.add_argument("--max_speed", type=float, default=0.30)
    parser.add_argument("--vel_deadzone", type=float, default=0.003)
    parser.add_argument(
        "--belt_speed",
        type=float,
        default=0.0,
        help=(
            "Known conveyor speed in m/s; 0 estimates velocity from mask "
            "centres captured during registration"
        ),
    )
    parser.add_argument(
        "--belt_direction",
        type=float,
        nargs=3,
        default=[1.0, 0.0, 0.0],
        metavar=("X", "Y", "Z"),
        help="Conveyor direction in camera coordinates",
    )
    parser.add_argument(
        "--motion_history_size",
        type=int,
        default=120,
        help="Maximum mask-centre samples retained during registration",
    )
    parser.add_argument(
        "--motion_outlier_threshold",
        type=float,
        default=0.02,
        help="Minimum residual threshold in metres for velocity-fit outliers",
    )
    parser.add_argument("--hyp_translation_step", type=float, default=0.025)
    parser.add_argument("--min_mask_iou", type=float, default=0.01)
    parser.add_argument("--max_bridge_attempts", type=int, default=3)
    parser.add_argument(
        "--mask_score_backend",
        choices=("auto", "renderer", "hull"),
        default="auto",
    )

    # Right-arm camera calibration and waypoint placeholders.
    parser.add_argument(
        "--calib",
        type=str,
        default=os.path.join(_code_dir, "realsense_pose_xp1.txt"),
        help="RealSense camera-to-right-arm-base 4x4 matrix",
    )
    parser.add_argument("--no_arm", action="store_true", help="Vision-only mode")
    parser.add_argument("--auto_grasp", action="store_true", help="Start one grasp automatically")
    parser.add_argument("--ur_host", type=str, default="192.168.100.1")
    parser.add_argument("--ur_port", type=int, default=30003,
                        help="Legacy compatibility option; motion now uses RTDE")
    parser.add_argument("--ur_acc", type=float, default=0.6)
    parser.add_argument("--ur_vel", type=float, default=0.5)
    parser.add_argument("--k_acc", type=float, default=1.0)
    parser.add_argument("--k_vel", type=float, default=1.0)
    parser.add_argument("--move_timeout", type=float, default=20.0)
    parser.add_argument(
        "--waypoints_file",
        type=str,
        default=None,
        help=(
            "Optional millimetre-based file containing 初始姿态, 中间姿态1, "
            "中间姿态2 and 放置姿态. If omitted, fill RIGHT_ARM_WAYPOINTS."
        ),
    )

    # Fixed TCP reference for following; select a directional effective height
    # once from the last predicted pose when freezing the final grasp target.
    parser.add_argument(
        "--tool_height",
        type=float,
        default=0.145,
        help="Fixed controller TCP offset in metres; use the TCP used to teach waypoints",
    )
    parser.add_argument(
        "--tool_height_z_down",
        type=float,
        default=0.15,
        help="Final grasp height if frozen predicted object +Z points down in robot base (m)",
    )
    parser.add_argument(
        "--tool_height_z_up",
        type=float,
        default=0.15,
        help="Final grasp height if frozen predicted object +Z points up in robot base (m)",
    )
    parser.add_argument(
        "--tcp_mode",
        choices=("controller", "software"),
        default="controller",
        help=(
            "controller uses a fixed tool_height TCP plus the directional height difference; "
            "software leaves the UR TCP unchanged and adds the full directional height to base Z"
        ),
    )
    parser.add_argument("--vacuum_io", type=int, default=5)
    parser.add_argument(
        "--vacuum_active_low",
        action="store_true",
        help="Use electrical LOW to enable the vacuum valve",
    )
    parser.add_argument("--vacuum_dwell", type=float, default=0.5)
    parser.add_argument("--release_dwell", type=float, default=0.3)

    # RTDE servoL runs independently of inference with bounded linear/angular
    # acceleration.  The ROI interception and pick/place sequence are retained.
    parser.add_argument("--grasp_yaw_deg", type=float, default=0.0)
    parser.add_argument(
        "--arm_predict_dt",
        type=float,
        default=1.8,
        help="Prediction horizon for both follow and frozen ROI interception (s)",
    )
    parser.add_argument(
        "--arm_roi_margin",
        type=int,
        default=50,
        help="ROI expansion used to switch from servo follow to frozen-pose movel (px)",
    )
    parser.add_argument("--approach_clearance", type=float, default=0.080)
    parser.add_argument("--contact_clearance", type=float, default=0.003)
    parser.add_argument("--post_grasp_lift", type=float, default=0.120)
    # Retained for command-line compatibility; ROI entry now replaces the old
    # hover/contact arrival state machine.
    parser.add_argument("--hover_reached_tolerance", type=float, default=0.015)
    parser.add_argument("--contact_reached_tolerance", type=float, default=0.008)
    parser.add_argument("--reached_hold_frames", type=int, default=3)
    parser.add_argument("--servo_rate", type=float, default=125.0)
    parser.add_argument("--servo_alpha", type=float, default=0.05)
    parser.add_argument(
        "--servo_lookahead",
        type=float,
        default=0.15,
        help="UR servoL lookahead in seconds",
    )
    parser.add_argument("--servo_gain", type=int, default=150)
    parser.add_argument("--max_cart_speed", type=float, default=0.2)
    parser.add_argument("--max_cart_accel", type=float, default=0.35,
                        help="Maximum servo setpoint acceleration in m/s^2")
    parser.add_argument("--max_angular_speed", type=float, default=0.5)
    parser.add_argument("--max_angular_accel", type=float, default=1.0,
                        help="Maximum servo setpoint angular acceleration in rad/s^2")
    parser.add_argument("--target_update_interval", type=float, default=0.03)
    parser.add_argument("--target_pos_threshold", type=float, default=0.001)
    parser.add_argument("--target_rot_threshold", type=float, default=0.035)
    parser.add_argument("--stop_deceleration", type=float, default=2.0)
    parser.add_argument("--arrival_pos_tolerance", type=float, default=0.010)
    parser.add_argument("--arrival_rot_tolerance", type=float, default=0.080)
    parser.add_argument("--arrival_settle_timeout", type=float, default=0.5,
                        help="Wait for TCP feedback after moveL completion (s)")
    parser.add_argument("--max_target_jump", type=float, default=0.20)
    parser.add_argument(
        "--workspace_min",
        type=float,
        nargs=3,
        default=[-1.5, -1.5, -0.1],
        metavar=("X", "Y", "Z"),
    )
    parser.add_argument(
        "--workspace_max",
        type=float,
        nargs=3,
        default=[1.5, 1.5, 1.5],
        metavar=("X", "Y", "Z"),
    )

    parser.add_argument("--no_show", action="store_true")
    parser.add_argument("--save_poses", action="store_true")
    parser.add_argument(
        "--max_frames",
        type=int,
        default=0,
        help="Stop after N processed frames; 0 means unlimited",
    )
    parser.add_argument(
        "--log_file",
        type=str,
        default="main_online_kalman_suction_fixed_z.log",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    set_logging_format()
    set_seed(0)
    _setup_logging(args.log_file)

    if args.hyp_translation_step <= 0.0:
        raise ValueError("--hyp_translation_step must be positive")
    if args.window_width <= 0 or args.window_height <= 0:
        raise ValueError("Window dimensions must be positive")
    if args.max_bridge_attempts < 1:
        raise ValueError("--max_bridge_attempts must be at least 1")
    if args.motion_history_size < 2:
        raise ValueError("--motion_history_size must be at least 2")
    if args.motion_outlier_threshold <= 0.0:
        raise ValueError("--motion_outlier_threshold must be positive")
    if args.max_speed <= 0.0:
        raise ValueError("--max_speed must be positive")
    if args.belt_speed < 0.0:
        raise ValueError("--belt_speed cannot be negative")
    if args.belt_speed > 0.0:
        _belt_velocity_from_args(args)
    for name in ("tool_height", "tool_height_z_down", "tool_height_z_up"):
        if not np.isfinite(getattr(args, name)) or getattr(args, name) < 0.0:
            raise ValueError(f"--{name} must be finite and non-negative")
    if not 0 <= args.vacuum_io <= 7:
        raise ValueError("--vacuum_io must be a UR standard digital output 0..7")
    if args.approach_clearance <= args.contact_clearance:
        raise ValueError("--approach_clearance must exceed --contact_clearance")
    if args.contact_clearance < 0.0 or args.post_grasp_lift <= 0.0:
        raise ValueError("Contact clearance must be non-negative and lift positive")
    if args.reached_hold_frames < 1:
        raise ValueError("--reached_hold_frames must be at least 1")
    if not 0.0 < args.servo_rate <= 125.0:
        raise ValueError("--servo_rate must be in (0, 125] for UR5/CB3 compatibility")
    for name in ("max_cart_speed", "max_cart_accel", "max_angular_speed", "max_angular_accel",
                 "ur_vel", "ur_acc", "k_vel", "k_acc", "stop_deceleration",
                 "arrival_settle_timeout"):
        if not np.isfinite(getattr(args, name)) or getattr(args, name) <= 0.0:
            raise ValueError(f"--{name} must be finite and positive")
    if not 0.0 < args.servo_alpha <= 1.0:
        raise ValueError("--servo_alpha must be in (0, 1]")
    if args.target_update_interval < 0.0:
        raise ValueError("--target_update_interval cannot be negative")
    if args.target_pos_threshold < 0.0 or args.target_rot_threshold < 0.0:
        raise ValueError("Target update thresholds cannot be negative")
    if args.arm_roi_margin < 0:
        raise ValueError("--arm_roi_margin cannot be negative")
    if not 0.03 <= args.servo_lookahead <= 0.20:
        raise ValueError("UR servoj lookahead must be in [0.03, 0.20] seconds")
    if not 100 <= args.servo_gain <= 2000:
        raise ValueError("UR servoj gain must be in [100, 2000]")
    if np.any(np.asarray(args.workspace_min) >= np.asarray(args.workspace_max)):
        raise ValueError("Every --workspace_min component must be below workspace_max")

    if not check_realsense_connection():
        logging.error("No Intel RealSense camera detected")
        return 2

    run(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
